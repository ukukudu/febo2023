import { RiCreativeCommonsZeroLine } from "react-icons/ri"
import { ses } from "../integrations/amazonSES"

const env = process.env.APP_ENV || process.env.NODE_ENV

type ResetPasswordMailer = {
  to: string
  token: string
}

export function forgotPasswordMailer({ to, token }: ResetPasswordMailer) {
  // In production, set APP_ORIGIN to your production server origin
  const origin = process.env.APP_ORIGIN || process.env.BLITZ_DEV_SERVER_ORIGIN
  const resetUrl = `${origin}/reset-password?token=${token}`

  const msg = {
    from: "Febo Super Timers <support@febo.app>",
    to,
    subject: "Forgot your password?",
    html: `
      <h1>Forgot your password?</h1>
      <div><p>It's okay, it happens. Click on the link below to reset your password.</p></div>

      <a href="${resetUrl}">
       Reset Password
      </a>
    `,
  }

  return {
    async send() {
      if (env === "production") {
        // TODO - send the production email, like this:
        await ses.sendMail(msg)
        // throw new Error("No production email implementation in mailers/forgotPasswordMailer")
      } else {
        const previewEmail = (await import("preview-email")).default
        return await previewEmail(msg)
      }
    },
  }
}
