import { resolver } from "@blitzjs/rpc"
import { NotFoundError } from "blitz"
import db, { Project } from "db"

export default resolver.pipe(resolver.authorize(), async ({ id }, ctx) => {
  const projects = await db.$queryRaw<Project[]>`
    SELECT p.*,
      Coalesce(Sum(t."todayTime"), 0) AS today,
      Coalesce(Sum(t."plannedTime"), 0) AS planned
    FROM "Project" p
      LEFT JOIN "List" l ON "projectId" = p.id
        LEFT JOIN "Task" t ON "listId" = l.id
    WHERE p."userId" = ${ctx.session.userId}
    GROUP  BY p.id
    ORDER BY p.position ASC
  `

  if (!projects) throw new NotFoundError()

  return projects
})
