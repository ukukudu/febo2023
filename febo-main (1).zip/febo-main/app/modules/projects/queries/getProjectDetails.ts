import { resolver } from "@blitzjs/rpc"
import db from "db"
import { Prisma } from "@prisma/client"
import * as z from "zod"
import { NotFoundError } from "blitz"

const GetStats = z.object({
  fromDate: z.string().optional(),
  untilDate: z.string().optional(),
  range: z.string().optional(),
})

type PlannedTime = {
  listId: string
  plannedTime: number
}

export default resolver.pipe(
  resolver.zod(GetStats),
  resolver.authorize(),
  async ({ fromDate, untilDate, range }, ctx): Promise<Array<PlannedTime>> => {
    const now = new Date()

    const rangeInDays = {
      Month: new Date(now.getFullYear(), now.getMonth(), 1),
      Week: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - (now.getDay() > 0 ? now.getDay() + 1 : 6)
      ),
      Today: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
    }

    const from = range ? rangeInDays[range] : fromDate ? new Date(fromDate) : now
    const until = range || !untilDate ? now : new Date(untilDate)

    // we have only one project for a user. So no need to query by project
    const query = Prisma.sql`SELECT l.id as "listId",
      SUM(t."plannedTime") as "plannedTime"
      FROM "List" l, "Task" t
      WHERE l."userId" = ${ctx.session.userId}
      AND l.deleted = false
      AND t.deleted = false
      AND l.done = false
      AND t.done = false
      AND t."listId" = l.id
      GROUP BY l.id
    `
    const planned = await db.$queryRaw<Array<PlannedTime>>(query)

    if (!planned) throw new NotFoundError()

    return planned
  }
)
