import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const DeleteProject = z
  .object({
    id: z.string(),
  })
  .nonstrict()

export default resolver.pipe(resolver.zod(DeleteProject), resolver.authorize(), async ({ id }) => {
  // TODO: in multi-tenant app, you must add validation to ensure correct tenant

  const listIds = await db.list.findMany({ where: { projectId: id }, select: { id: true } })

  // console.log(listIds)

  for await (const entry of listIds) {
    await db.task.deleteMany({ where: { listId: entry.id as any } })
  }

  await db.list.deleteMany({ where: { projectId: id } })

  const project = await db.project.deleteMany({ where: { id } })

  return project
})
