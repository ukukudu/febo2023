import { resolver } from "@blitzjs/rpc";
import { Ctx } from "blitz";
import db from "db"
import * as z from "zod"

const CreateProject = z
  .object({
    name: z.string(),
  })
  .nonstrict()

export default resolver.pipe(
  resolver.zod(CreateProject),
  resolver.authorize(),
  async (input: z.infer<typeof CreateProject>, ctx: Ctx) => {
    // TODO: in multi-tenant app, you must add validation to ensure correct tenant
    const data: any = CreateProject.parse({ ...input, userId: ctx.session.userId })

    const prevProjects = await db.project.findMany({ where: { userId: data.userId } })

    const positionUpdate = prevProjects.map((p) =>
      db.project.update({ where: { id: p.id }, data: { position: p.position! + 1 } })
    )

    const project = db.project.create({ data: { ...data, position: 0 } })

    await db.$transaction([...positionUpdate, project])

    return project
  }
)
