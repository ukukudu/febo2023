import { resolver } from "@blitzjs/rpc";
import { Ctx } from "blitz";
import db from "db"

export default resolver.pipe(resolver.authorize(), async (_, ctx: Ctx) => {
  await db.task.deleteMany({ where: { userId: ctx.session.userId! } })
  await db.list.deleteMany({ where: { userId: ctx.session.userId! } })
  return db.project.deleteMany({ where: { userId: ctx.session.userId! } })
})
