import { resolver } from "@blitzjs/rpc";
import db, { Project } from "db"
import * as z from "zod"

const UpdateProject = z.array(
  z.object({
    id: z.string(),
    position: z.number(),
  })
)

export default resolver.pipe(
  resolver.zod(UpdateProject),
  resolver.authorize(),
  async (projects, ctx) => {
    const projectUpdatePosition = projects.map((row) =>
      db.project.update({ where: { id: row.id }, data: row })
    )

    await db.$transaction(projectUpdatePosition)
  }
)
