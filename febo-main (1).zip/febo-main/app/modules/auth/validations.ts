import * as z from "zod"

const password = z.string().min(8).max(100)
const captchaDisabled = process.env.CAPTCHA_DISABLED == "true"

export const Signup = z
  .object({
    name: z.string(),
    email: z.string().email(),
    password,
    termsAccepted: z.boolean().optional(),
    captcha: captchaDisabled ? z.undefined() : z.string().optional(),
  })
  .refine((data) => data.termsAccepted, {
    message: "Please accept our Terms of Service and Privacy Policy",
    path: ["termsAccepted"],
  })

export const Login = z.object({
  email: z.string().email(),
  password: z.string(),
})

export const ForgotPassword = z.object({
  email: z.string().email(),
})

export const ResetPassword = z
  .object({
    password,
    passwordConfirmation: password,
    token: z.string(),
  })
  .refine((data) => data.password === data.passwordConfirmation, {
    message: "Passwords don't match",
    path: ["passwordConfirmation"], // set the path of the error
  })

export const ChangePassword = z.object({
  currentPassword: z.string(),
  newPassword: password,
})
