import Link from "next/link"
import { useRouter } from "next/router"
import { useSession } from "@blitzjs/auth"
import { Routes } from "@blitzjs/next"
import { useMutation } from "@blitzjs/rpc"
import { LabeledTextField } from "app/core/components/LabeledTextField"
import { Form, FORM_ERROR } from "app/core/components/Form"
import login from "app/modules/auth/mutations/login"
import { Login } from "app/modules/auth/validations"
import { Box, Heading } from "@chakra-ui/react"
import React from "react"
import { useEffect } from "react"
import { AuthenticationError } from "blitz"

type LoginFormProps = {
  onSuccess?: () => void
}

const LoginForm = (props: LoginFormProps) => {
  const [loginMutation] = useMutation(login)
  const session = useSession()
  const routes = useRouter()

  useEffect(() => {
    if (!["/", "/login"].includes(routes.pathname) && !session.userId) {
      localStorage.clear()
      window.location.href = "/login"
    }
    // if (session.userId) {
    //   window.location.reload()
    // }
  }, [session.userId, routes])

  return (
    <>
      <Heading as="h1" mb={8}>
        Login
      </Heading>

      <Form
        submitText="Login"
        schema={Login}
        initialValues={{ email: "", password: "" }}
        onSubmit={async (values) => {
          try {
            // @ts-ignore
            await loginMutation(values)
            props.onSuccess?.()
          } catch (error) {
            if (error instanceof AuthenticationError) {
              return { [FORM_ERROR]: "Sorry, those credentials are invalid" }
            }
            return {
              [FORM_ERROR]: `Sorry, we had an unexpected error. Please try again. - ${error.toString()}`,
            }
          }
        }}
      >
        <LabeledTextField name="email" label="Email" placeholder="Email" />
        <LabeledTextField name="password" label="Password" placeholder="Password" type="password" />
        <div>
          <Link href={Routes.ForgotPasswordPage()}>Forgot your password?</Link>
        </div>
      </Form>

      <Box mt={4}>
        Or <Link href={Routes.SignupPage()}>Sign Up</Link>
      </Box>
    </>
  )
}

export default LoginForm
