import Link from "next/link"
import { useMutation } from "@blitzjs/rpc"
import { useMemo, useState } from "react"
import { Box, Checkbox, Flex, Heading, SimpleGrid } from "@chakra-ui/react"
import styled from "@emotion/styled"
import { Form, FORM_ERROR } from "app/core/components/Form"
import { LabeledTextField } from "app/core/components/LabeledTextField"
import Logo from "app/core/media/febo_dark_logo-v2.svg"
import signup from "app/modules/auth/mutations/signup"
import { Signup } from "app/modules/auth/validations"
import passStrength from "password-strength-calc"
import { HiOutlineEye, HiOutlineEyeOff } from "react-icons/hi"
import { LabledCheckbox } from "app/core/components/LabledCheckbox"
import Captcha from "app/auth/components/Captcha"

type SignupFormProps = {
  onSuccess?: () => void
}

const SignupCard = styled(Box)`
  background-color: #fff;
  padding: 3rem;
  width: 30%;
  min-width: 450px;
  margin: auto;
  @media screen and (max-width: 768px) {
    /* width: 90%; */
    min-width: 90%;
    padding: 1.5rem;
  }
`

const SignupForm = (props: SignupFormProps) => {
  const [signupMutation] = useMutation(signup)
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [show, setShow] = useState(false)
  const showPassword = () => setShow(!show)
  const [password, setPassword] = useState("")

  const strength = useMemo(() => {
    return passStrength(password)
  }, [password])

  const color = useMemo(() => {
    if (strength < 25) return "red.500"
    if (strength >= 25 && strength < 50) return "orange.400"
    if (strength >= 50 && strength < 75) return "green.700"
    if (strength >= 75 && strength <= 100) return "green.400"
  }, [strength])

  return (
    <Flex my="auto" direction="column">
      <Box as={Logo} color="white" w={150} mb={4} mx="auto" />
      <SignupCard>
        <Heading as="h1" fontSize={22} mb={8} color="gray" opacity="0.8" textAlign="center">
          Sign up for your account
        </Heading>
        <Form
          submitText="Sign up"
          schema={Signup}
          initialValues={{ email: "", password: "", name: "" }}
          onSubmit={async (values) => {
            // console.log(values)
            try {
              await signupMutation(values)
              props.onSuccess?.()
            } catch (error) {
              if (error.code === "P2002" && error.meta?.target?.includes("email")) {
                // This error comes from Prisma
                return { email: "This email is already being used" }
              }
              return { [FORM_ERROR]: error.toString() }
            }
          }}
        >
          <LabeledTextField name="email" label="" placeholder="Enter your email" />
          <LabeledTextField name="name" label="" placeholder="Enter full name" />
          <LabeledTextField
            label=""
            name="password"
            placeholder="Create password"
            type={show ? "text" : "password"}
            showPassword={showPassword}
            onChange={(e) => {
              setPassword(e.target.value)
            }}
            icon={show ? <HiOutlineEyeOff /> : <HiOutlineEye />}
          />
          <SimpleGrid columns={4} spacing={2}>
            <Box h={1} bg={password === "" && strength < 25 ? "gray.200" : color} />
            <Box h={1} bg={strength <= 25 ? "gray.200" : color} />
            <Box h={1} bg={strength <= 50 ? "gray.200" : color} />
            <Box h={1} bg={strength <= 75 ? "gray.200" : color} />
          </SimpleGrid>

          <Flex style={{ marginTop: "48px" }}>
            <LabledCheckbox name="termsAccepted">
              <p style={{ marginLeft: "8px" }}>
                I agree to the&nbsp;
                <span style={{ opacity: "0.7", cursor: "pointer", textDecoration: "underline" }}>
                  <Link target="_blank" href="https://febo.app/legal/terms-of-service">
                    Terms of Service
                  </Link>
                </span>
                &nbsp;and{" "}
                <span style={{ opacity: "0.7", cursor: "pointer", textDecoration: "underline" }}>
                  <Link target="_blank" href="https://febo.app/legal/privacy-policy">
                    Privacy Policy
                  </Link>
                </span>
              </p>
            </LabledCheckbox>
          </Flex>
          <Captcha />
        </Form>
        <Box textAlign="center" my={2}>
          Already have an account?{" "}
          <Box
            css={{ display: "inline-block", cursor: "pointer" }}
            onClick={() => (window.location.href = "/login")}
          >
            Log In
          </Box>
        </Box>
      </SignupCard>
    </Flex>
  )
}

export default SignupForm
