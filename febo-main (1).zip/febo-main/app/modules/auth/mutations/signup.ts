import { SecurePassword } from "@blitzjs/auth"
import { resolver } from "@blitzjs/rpc"
import db from "db"
import { Signup } from "app/modules/auth/validations"
import { Role } from "types"
import { verifyCaptcha } from "integrations/Captcha"

// const env = process.env.APP_ENV || process.env.NODE_ENV
// const captchaDisabled = process.env.CAPTCHA_DISABLED == "true"

export default resolver.pipe(
  resolver.zod(Signup),
  async ({ name, email, password, captcha }, ctx) => {
    const hashedPassword = await SecurePassword.hash(password.trim())

    await verifyCaptcha(captcha)

    const user = await db.user.create({
      data: {
        name: name,
        email: email.toLowerCase().trim(),
        hashedPassword,
        role: "USER",
      },
      select: { id: true, name: true, email: true, role: true, stripeId: true },
    })

    await db.user.update({
      where: { id: user.id },
      data: {
        projects: {
          create: {
            name: "default",
          },
        },
      },
    })

    const project = await db.project.findFirst({ select: { id: true }, where: { user } })
    if (!project?.id) {
      throw new Error("Default project missing.")
    }

    await ctx.session.$create({
      userId: user.id,
      role: user.role as Role,
      projectId: project?.id,
    })
    return user
  }
)
