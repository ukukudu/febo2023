import { useQuery } from "@blitzjs/rpc"
import { ReactElement } from "react"
import getStripePrices from "app/modules/stripe/queries/get-prices"
import { Box, Button, Flex, SimpleGrid, StackDivider, VStack } from "@chakra-ui/react"
import { neofetch } from "app/core/lib/neofetch"

import { Stripe, loadStripe } from "@stripe/stripe-js"
import getCurrentUser from "../../../users/queries/getCurrentUser"

export interface IProductsProps {}

let stripePromise: Promise<Stripe | null>
const getStripe = () => {
  if (!stripePromise) {
    // TODO: move this to a variable
    stripePromise = loadStripe("pk_live_vCzs4NAuViWpywEcbQ1G9NZq")
  }
  return stripePromise
}

export function Products({ ...props }: IProductsProps): ReactElement {
  const [prices] = useQuery(getStripePrices, null, { staleTime: 1000 * 60 * 10 })
  const [user] = useQuery(getCurrentUser, null)

  const handleSubmit = async (priceId: string, mode) => {
    // @ts-ignore
    const response = await neofetch.post("/api/checkout-sessions", {
      customerId: user?.stripeId,
      priceId,
      mode,
    })

    if (response.statusCode === 500) {
      console.error(response.message)
      return
    }

    // Redirect to Checkout.
    const stripe = await getStripe()
    const { error } = await stripe!.redirectToCheckout({
      // Make the id field from the Checkout Session creation API response
      // available to this file, so you can provide it as parameter here
      // instead of the {{CHECKOUT_SESSION_ID}} placeholder.
      sessionId: response.id,
    })
    // If `redirectToCheckout` fails due to a browser or network
    // error, display the localized error message to your customer
    // using `error.message`.
    console.warn(error.message)
    // setLoading(false)
  }

  return (
    <>
      {/* <SimpleGrid
        direction="row"
        spacing={8}
        columns={{ base: 1, md: 2, xl: prices.length <= 4 ? prices.length : 4 }}
        px={{ base: 4, md: 8, xl: 16 }}
      > */}
      <VStack divider={<StackDivider borderColor="gray.200" />} spacing={4} align="stretch">
        {prices.map((price, key) => (
          <Flex direction="column" key={key}>
            <Box
              textAlign="center"
              bg="black"
              color="white"
              fontSize={28}
              textTransform="uppercase"
              fontWeight="bold"
              borderRadius="xl"
              py={4}
              transform="translateY(25%)"
            >
              {price.name}
            </Box>
            <Flex
              bg="yellow.100"
              borderRadius="xl"
              direction="column"
              flex={1}
              px={8}
              pb={4}
              pt={12}
              alignItems="center"
              border="1px solid"
              borderColor="gray.600"
            >
              <Flex alignItems="flex-start" fontWeight="bold" mt={3}>
                <Box mr={1}>$</Box>
                <Box fontSize={48} lineHeight={1}>
                  {price?.price.toString().split(".")[0]}
                </Box>
                <Box>{price?.price.toString().split(".")[1]}</Box>
              </Flex>
              <Box my={4} dangerouslySetInnerHTML={{ __html: price.description || "" }} />
              <Button
                colorScheme="orange"
                mt="auto"
                w="full"
                borderRadius="xl"
                textAlign="center"
                height="42px"
                onClick={() => handleSubmit(price.id, price.mode)}
              >
                UPGRADE
              </Button>
            </Flex>
          </Flex>
        ))}
      </VStack>
    </>
  )
}
