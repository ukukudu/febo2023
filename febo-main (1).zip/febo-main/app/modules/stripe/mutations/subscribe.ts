import { resolver } from "@blitzjs/rpc";
import { Ctx } from "blitz";
import db from "db"
import * as z from "zod"
import { stripe } from "../client"

const Subscribe = z
  .object({
    sessionId: z.string(),
  })
  .nonstrict()

export default resolver.pipe(
  resolver.zod(Subscribe),
  resolver.authorize(),
  async ({ sessionId }: z.infer<typeof Subscribe>, ctx: Ctx) => {
    const session = await stripe.checkout.sessions.retrieve(sessionId)

    if (session?.subscription) {
      const user = await db.user.update({
        where: { id: ctx.session.userId! },
        data: {
          stripeSubscriptionId: session.subscription as any,
        },
      })
    }

    return session
  }
)

// const session = await stripe.checkout.sessions.retrieve(
//   'cs_test_BFMFpKrtQGMzMxkv8UdW56n9BHLFDL1I5DFsVfDT6DtJuORe1dBVYsrM'
// );
