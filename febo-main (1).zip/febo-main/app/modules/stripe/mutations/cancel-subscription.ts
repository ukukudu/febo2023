import { resolver } from "@blitzjs/rpc";
import { Ctx } from "blitz";
import db from "db"
import { stripe } from "../client"

export default resolver.pipe(resolver.authorize(), async (_, ctx: Ctx) => {
  console.log("got this")
  const user = await db.user.findUnique({
    where: {
      id: ctx.session.userId!,
    },
  })

  if (!user?.stripeSubscriptionId) return null
  const deleted = await stripe.subscriptions.del(user.stripeSubscriptionId!)
  await db.user.update({
    where: { id: ctx.session.userId! },
    data: {
      stripeSubscriptionId: null,
    },
  })

  return deleted
})
