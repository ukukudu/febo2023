import { SetIdentityFeedbackForwardingEnabledCommandInput } from "@aws-sdk/client-ses"
import { Ctx } from "blitz"
import { stripe } from "../client"

type Price = {
  name: string
  id: string
  mode: "subscription" | "payment"
  description: string | null
  price: number
  currency: string
}

export default async function getStripePrices(_ = null, { session }: Ctx) {
  const prices = await stripe.prices.list()

  const data: Price[] = []
  for await (let price of prices.data) {
    const product = await stripe.products.retrieve(price?.product as string)

    if (!product.active) continue
    data.push({
      name: product.name,
      id: price.id,
      mode: price.recurring ? "subscription" : "payment",
      description: product.description,
      price: price?.unit_amount || 0 / 100,
      currency: price.currency,
    })
  }

  // const data = await products.data.map(async (product) => {
  //   return { name: product.name }
  // })
  return data.reverse()
}
