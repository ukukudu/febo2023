import { Ctx } from "blitz"
import db from "db"
import { stripe } from "../client"

export default async function getSubscription({ id }, ctx: Ctx) {
  if (!ctx.session.userId) return { status: "none" }

  const user = await db.user.findUnique({
    where: {
      id: ctx.session.userId,
    },
  })

  if (!user?.stripeSubscriptionId) return { status: "none" }

  const subscription: any = await stripe.subscriptions.retrieve(user.stripeSubscriptionId!)

  return subscription
  //
  // const charges = await stripe.invoices.list({
  //   customer: id,
  // })
  //
  // const lifetime = charges.data.some(
  //   // @ts-ignore
  //   (entry) => entry.status === "succeeded" && entry.amount === 5999
  // )
  //
  // console.log(lifetime)
  //
  // return subscription?.data[0]
}
