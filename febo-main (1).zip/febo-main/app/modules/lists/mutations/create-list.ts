import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const CreateList = z.object({
  name: z.string(),
})

export default resolver.pipe(
  resolver.zod(CreateList),
  resolver.authorize(),
  async ({ name }, ctx) => {
    const count = await db.list.count({
      where: {
        userId: ctx.session.userId,
      },
    })

    const list = await db.list.create({
      data: {
        name,
        projectId: ctx.session.projectId,
        position: count,
        userId: ctx.session.userId,
      },
    })

    return list
  }
)
