import { resolver } from "@blitzjs/rpc";
import db, { Prisma } from "db"
import * as z from "zod"

const DeleteList = z.object({
  id: z.string(),
})

export default resolver.pipe(
  resolver.zod(DeleteList),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const list = await db.list.findFirst({ where: { id, userId: ctx.session.userId } })

    const updateList = await db.list.update({ where: { id }, data: { done: true } })
    return updateList
  }
)
