import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const CreateManyList = z.array(
  z.object({
    name: z.string(),
    projectId: z.string(),
  })
)

export default resolver.pipe(
  resolver.zod(CreateManyList),
  resolver.authorize(),
  async (input, ctx) => {
    const count = await db.list.count({
      where: {
        userId: ctx.session.userId,
      },
    })

    const newInputs = input.map((item, i) => {
      return { ...item, position: count + i, userId: ctx.session.userId }
    })

    const list = await db.list.createMany({
      data: newInputs,
    })

    return list
  }
)
