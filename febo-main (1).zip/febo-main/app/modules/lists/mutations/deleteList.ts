import { resolver } from "@blitzjs/rpc";
import db, { Prisma } from "db"
import * as z from "zod"

const DeleteList = z.object({
  id: z.string(),
  hard: z.boolean().default(false),
})

export default resolver.pipe(
  resolver.zod(DeleteList),
  resolver.authorize(),
  async ({ id, hard }) => {
    const list = await (hard
      ? db.$queryRaw(Prisma.sql`DELETE FROM "List" WHERE id=${id}`)
      : db.list.deleteMany({ where: { id } }))
    return list
  }
)
