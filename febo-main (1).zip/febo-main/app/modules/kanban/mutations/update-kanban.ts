import { resolver } from "@blitzjs/rpc";
import db from "db"
// import * as z from "zod"

// const UpdateKanban = z
//   .object({
//     id: z.string(),
//   })
//   .nonstrict()

export default resolver.pipe(resolver.authorize(), async ({ columnOrder, columns }, ctx) => {
  const listPositions = columnOrder.map((id, index) =>
    db.list.updateMany({
      where: {
        id,
        userId: ctx.session.userId,
      },
      data: {
        position: index,
      },
    })
  )

  const taskPositions = Object.values(columns).flatMap(({ id, taskIds }) => {
    return taskIds.map((taskId, index) =>
      db.task.updateMany({
        where: {
          id: taskId,
          userId: ctx.session.userId,
        },
        data: {
          position: index,
          listId: id,
        },
      })
    )
  })

  await db.$transaction([...listPositions, ...taskPositions])
})
