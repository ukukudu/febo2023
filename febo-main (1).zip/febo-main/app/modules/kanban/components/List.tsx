import { useSession } from "@blitzjs/auth"
import { useParam } from "@blitzjs/next"
import { useMutation } from "@blitzjs/rpc"
/* eslint-disable max-classes-per-file */

import { Component, useCallback, useMemo } from "react"
import { Box, Button, Flex, ScaleFade } from "@chakra-ui/react"
import styled from "@emotion/styled"
import Currency from "app/core/components/Currency"
import { TimeString } from "app/core/components/TimeString"
import { useCurrentUser } from "app/core/hooks/use-current-user"
import { ScrollElement } from "app/core/hooks/use-scroll"
import { useStore } from "app/core/lib/store"
import createList from "app/modules/lists/mutations/create-list"
import markDoneList from "app/modules/lists/mutations/markDoneList"
import updateList from "app/modules/lists/mutations/update-list"
import createTask from "app/tasks/mutations/create-task"
import { Draggable, Droppable } from "react-beautiful-dnd"
import { IconContext } from "react-icons"
import { HiCheckCircle, HiPlus } from "react-icons/hi"
import CustomEditableInput from "./CustomEditableInput"
import Task from "./Task"

const Container = styled.div`
  margin: 8px;
  margin-left: 0px;
  border-radius: 12px;
  width: 240px;
  min-width: 175px;
  display: flex;
  flex-direction: column;
  height: fit-content;
`
const TaskList = styled.div`
  padding: 8px;
  transition: background-color 0.2s ease;
  /* background-color: ${(props: any) => (props.isDraggingOver ? "mediumseagreen" : "inherit")}; */
  flex-grow: 1;
  min-height: 48px;
`
const AddTaskButton = styled(Button)`
  font-size: 16px;
  background-color: transparent;
  border: 1px solid #19012b;
  display: flex;
  opacity: 0.8;
  &:hover {
    background-color: transparent;
    color: #000;
  }
  &:focus {
    box-shadow: none;
  }
`
const backgroundColorOpacity = "rgba(32, 32, 32, 0.3)"

class InnerList extends Component<any, any> {
  shouldComponentUpdate(nextProps) {
    return nextProps.tasks !== this.props.tasks
  }

  render() {
    return this.props.tasks.map((task, index) => (
      <Task
        key={task.id}
        task={task}
        list={this.props.list}
        index={index}
        selectedTimer={this.props.selectedTimer}
      />
    ))
  }
}

export default function List({ refetch, list, selectedTimer = "money", tasks, ...props }: any) {
  const session = useSession()
  const user = useCurrentUser()
  const projectId = useParam("projectId", "string")

  const [updateListMutation] = useMutation(updateList)
  const [markDoneListMutation] = useMutation(markDoneList)
  const [createTaskMutation] = useMutation(createTask)
  const [createListMutation] = useMutation(createList)
  const { excludedLists, isDragDisable, activeTask, set: setStore } = useStore((state) => state)

  list.time = useMemo<number>((): number => {
    return tasks.reduce((acc, task) => acc + task.duration, 0)
    // + (task.id === activeTask ? 100 : 0), 0)
  }, [tasks])

  list.plannedTime = useMemo<number>((): number => {
    return tasks.reduce((acc, task) => acc + task.plannedTime, 0)
  }, [tasks])

  const create = async () => {
    await createTaskMutation({ name: "", listId: list.id } as any)
    await refetch()

    // TODO check if this is needed, if yes optimze query.
    // await refetchAllTaks()
  }
  const mutate = async (payload) => {
    await updateListMutation({ ...payload, id: list.id })
    await refetch()
  }

  const markDone = useCallback(async () => {
    if (!activeTask) {
      await markDoneListMutation({ id: list.id })
      await refetch()
    }
  }, [activeTask, markDoneListMutation, list.id, refetch])

  const switchExclude = useCallback(async () => {
    let tmpExcluded = new Set(excludedLists)

    if (tmpExcluded.has(list.id)) {
      tmpExcluded.delete(list.id)
      setStore((s) => ({ ...s, excludedLists: Array.from(tmpExcluded) }))
    } else {
      setStore((s) => ({ ...s, excludedLists: Array.from(tmpExcluded.add(list.id)) }))
    }
  }, [excludedLists, list.id, setStore])

  const handlePressEnter = async (e: any) => {
    if (e.key === "Enter" && e.target.defaultValue !== "" && props.focusInputOnAddList) {
      await createListMutation({ name: "", projectId: projectId } as any)
      await refetch()
      ScrollElement(500, true)
    }
  }

  return (
    <Draggable draggableId={list.id} index={props.index} isDragDisabled={isDragDisable}>
      {(provided) => (
        <Box {...provided.draggableProps} {...provided.dragHandleProps} ref={provided.innerRef}>
          <Box
            onClick={switchExclude}
            cursor="pointer"
            opacity={excludedLists.includes(list.id) ? "16%" : undefined}
            color="white"
            fontSize={20}
            fontWeight={700}
            alignContent="center"
            // align="center"
          >
            {(() => {
              switch (selectedTimer) {
                case "planned":
                  return (
                    <TimeString
                      unstyled={true}
                      time={list.plannedTime || 0}
                      roundStrategy={"floor"}
                    />
                  )
                case "money":
                  return (
                    <Currency currency={user?.currency || undefined}>
                      {(Number(list.time / 1000 / 3600) * (user?.hourlyRate || 100)).toFixed(2)}
                    </Currency>
                  )
                default:
                  return (
                    <TimeString unstyled={true} time={list.time || 0} roundStrategy={"floor"} />
                  )
              }
            })()}
          </Box>
          <Flex>
            {/* <Editable
            isPreviewFocusable={true}
            submitOnBlur={true}
            fontSize={20}
            fontWeight="bold"
            // lineHeight={1.125}
            defaultValue={list.name}
            onSubmit={(v) => {
              if (v === "") {
                deleteList()
              } else {
                mutateList({ name: v })
              }
            }}
            // onBlur={async (e: any) => {
            //   if (e.target.value === "") {
            //     deleteList()
            //   }
            // }}
            onKeyDown={handlePressEnter}
            placeholder="Untitled"
          >
            <EditablePreview />
            <EditableInput as={TextareaAutosize} />
            <EditableControls
              focus={props.focusInputOnAddList}
              inputValue={list.name}
              index={props.index}
            />
          </Editable> */}
            <ScaleFade initialScale={0} in={true}>
              <Box as={Container} backgroundColor={backgroundColorOpacity}>
                <Flex alignItems="center" p={4}>
                  <Box color="white" opacity="100%" w="full">
                    <CustomEditableInput
                      defaultValue={list.name}
                      onBlur={async (v) => {
                        setStore((s) => ({ ...s, isDragDisable: false }))
                        if (v === " ") {
                          await markDone()
                        } else {
                          await mutate({ name: v })
                        }
                      }}
                      onFocus={() => {
                        setStore((s) => ({ ...s, isDragDisable: true }))
                      }}
                      onKeyDown={handlePressEnter}
                      placeholder="Untitled"
                    />
                  </Box>
                  <Box as="button" className={`list_${list.id}`} onClick={markDone}>
                    <Box as={HiCheckCircle} w={4} h={4} color="gray.500" />
                  </Box>
                </Flex>

                <Droppable droppableId={list.id} type="task">
                  {(provided, snapshot) => (
                    <TaskList
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      isDraggingOver={snapshot.isDraggingOver}
                    >
                      <InnerList
                        selectedTimer={selectedTimer}
                        tasks={tasks}
                        list={{ id: list.id, name: list.name }}
                      />
                      {provided.placeholder}
                    </TaskList>
                  )}
                </Droppable>
                <Box py={4} color="white" m="auto">
                  <AddTaskButton variant="solid" onClick={create}>
                    <IconContext.Provider
                      value={{ style: { marginTop: "3px", fontSize: "1.5rem" } }}
                    >
                      <HiPlus />
                    </IconContext.Provider>
                    Add
                  </AddTaskButton>
                </Box>
              </Box>
            </ScaleFade>
          </Flex>
        </Box>
      )}
    </Draggable>
  )
}
