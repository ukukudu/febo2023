import { useRouter } from "next/router"
import { setQueryData, useMutation, useQuery } from "@blitzjs/rpc"
import { Box, Flex, Text } from "@chakra-ui/react"
import styled from "@emotion/styled"
import { ScrollElement } from "app/core/hooks/use-scroll"
import { timeDiff } from "app/core/lib/helper"
import { useGlobalTimerUpdater, useStore } from "app/core/lib/store"
import { projectTemplate } from "app/core/lib/templates"
import getRunningTask from "app/users/queries/getRunningTask"
import getKanban from "app/modules/kanban/queries/get-kanban"
import createListFn from "app/modules/lists/mutations/create-list"
import createManyListFn from "app/modules/lists/mutations/create-many-list"
import { ReactElement, useCallback, useEffect, useRef } from "react"
import { DragDropContext, Droppable } from "react-beautiful-dnd"
import { IconContext } from "react-icons"
import { HiPlus } from "react-icons/hi"
import { useCurrentUser } from "app/core/hooks/use-current-user"
import deleteListFn from "../../lists/mutations/deleteList"
import updateKanban from "../mutations/update-kanban"
import List from "./List"

const Container = styled.div`
  display: flex;
  > div {
    height: fit-content;
  }
`

// const CustomEditableInput = styled(EditableInput)`
//   &:focus {
//     box-shadow: 0 0 5px #ffa500;
//   }
// `

const OutsidePlaceholder = styled.div`
  position: fixed;
  inset: 11rem 0px 0px 350px;
  height: calc(100% - 193px);
  width: calc(100% - 366px);
`

const ProjectWrapper = styled.div`
  position: relative;
  @media screen and (max-width: 767px) {
    margin-top: -3rem;
  }
`

function InnerList({
  refetch,
  column,
  taskMap,
  index,
  focusInputOnAddList,
  project,
  selectedTimer,
}: any) {
  const tasks = column.taskIds.map((taskId) => taskMap[taskId])
  return (
    <List
      refetch={refetch}
      list={column}
      tasks={tasks}
      focusInputOnAddList={focusInputOnAddList}
      index={index}
      project={project}
      selectedTimer={selectedTimer}
    />
  )
}

export function Project(): ReactElement {
  const user = useCurrentUser()
  const routes = useRouter()
  const { selectedTimer, range, set: setStore } = useStore((state) => state)

  const [runningTask, { refetch: refetchRunningTask }] = useQuery(getRunningTask, {})

  // init plannedTimer
  const updateGlobalTimers = useGlobalTimerUpdater()

  const [data, { refetch }] = useQuery(getKanban, { range })
  const [createListMutation] = useMutation(createListFn)
  const [updateKanbanMutation] = useMutation(updateKanban)
  const [deleteListMutation] = useMutation(deleteListFn)
  const [createManyListMutation] = useMutation(createManyListFn)

  const containerRef = useRef<any>()

  useEffect(() => {
    setTimeout(async () => {
      const element: any = document.querySelector(".editablHeading")
      if (element) {
        if (data.project && ["", "New project"].includes(data.project.name)) {
          const projectId = data.project.id
          element.click()
          const templateName = projectTemplate[user?.template as any]
          if (templateName !== "No Template") {
            const result = templateName.split("|").map((name: string) => {
              return { name: name.trim(), projectId }
            })
            await createManyListMutation(result as any)
            await refetch()
          }
        }
      }
      await updateGlobalTimers()
    }, 10)
  }, [routes])

  // set running Task
  useEffect(() => {
    setTimeout(async () => {
      if (runningTask?.id) {
        setStore((s) => ({
          ...s,
          activeTask: runningTask.id,
          sessionRunning: true,
          sessionStartedAt: runningTask.startedAt,
          sessionTime: timeDiff(
            (runningTask.startedAt && new Date(runningTask.startedAt).getMilliseconds()) ||
              Date.now()
          ),
        }))
      }
    }, 10)
  }, [routes, refetch, refetchRunningTask, setStore, runningTask])

  const createList = useCallback(async () => {
    await createListMutation({ name: "", projectId: data.project?.id } as any)
    await refetch()
    ScrollElement(500, true)
  }, [data.project?.id])

  const mutateKanban = async (payload) => {
    await setQueryData(getKanban, { range }, payload, { refetch: false })
    await updateKanbanMutation({ columnOrder: payload.columnOrder, columns: payload.columns })
  }

  // ************************************

  const onDragEnd = async (result) => {
    const { destination, source, draggableId, type } = result

    if (!destination) {
      return
    }

    if (destination.droppableId === source.droppableId && destination.index === source.index) {
      return
    }

    if (type === "column") {
      const newColumnOrder = Array.from(data.columnOrder)
      newColumnOrder.splice(source.index, 1)
      newColumnOrder.splice(destination.index, 0, draggableId)

      const newState = {
        ...data,
        columnOrder: newColumnOrder,
      }
      await mutateKanban(newState)
      return
    }

    const home = data.columns[source.droppableId]
    const foreign = data.columns[destination.droppableId]

    if (home === foreign) {
      const newTaskIds = Array.from(home.taskIds)
      newTaskIds.splice(source.index, 1)
      newTaskIds.splice(destination.index, 0, draggableId)

      const newHome = {
        ...home,
        taskIds: newTaskIds,
      }

      const newState = {
        ...data,
        columns: {
          ...data.columns,
          [newHome.id]: newHome,
        },
      }

      await mutateKanban(newState)
      return
    }

    // moving from one list to another
    const homeTaskIds = Array.from(home.taskIds)
    homeTaskIds.splice(source.index, 1)
    const newHome = {
      ...home,
      taskIds: homeTaskIds,
    }

    const foreignTaskIds = Array.from(foreign.taskIds)
    foreignTaskIds.splice(destination.index, 0, draggableId)
    const newForeign = {
      ...foreign,
      taskIds: foreignTaskIds,
    }

    const newState = {
      ...data,
      columns: {
        ...data.columns,
        [newHome.id]: newHome,
        [newForeign.id]: newForeign,
      },
    }
    await mutateKanban(newState)
  }

  const handleDeleteCard = async () => {
    const result = await refetch()
    if (Object.keys(result).length) {
      setTimeout(async () => {
        const newResult = (result as any).data.columns[
          (result as any).data.columnOrder[(result as any).data.columnOrder.length - 1] as any
        ]
        if (newResult?.name === "") {
          await deleteListMutation({ id: newResult.id })
          await refetch()
        }
      }, 100)
    }
  }

  return (
    <ProjectWrapper>
      <Flex style={{ position: "relative", zIndex: 2 }}>
        <DragDropContext onDragEnd={onDragEnd}>
          <Droppable droppableId="all-columns" direction="horizontal" type="column">
            {(provided) => (
              <Container {...provided.droppableProps} ref={provided.innerRef}>
                {(data as any).columnOrder.map((columnId, index) => {
                  const column = data.columns[columnId]

                  return (
                    <InnerList
                      refetch={refetch}
                      key={column.id}
                      focusInputOnAddList={index === (data as any).columnOrder.length - 1}
                      column={column}
                      project={data?.project}
                      index={index}
                      taskMap={data.tasks}
                      selectedTimer={selectedTimer}
                    />
                  )
                })}
                {provided.placeholder}
              </Container>
            )}
          </Droppable>
        </DragDropContext>

        <Box>
          <Text color="white" fontSize={20} fontWeight={700} align="center" />
          <Box
            onClick={createList}
            marginTop={12}
            style={{
              minWidth: "190px",
              maxHeight: "180px",
              marginLeft: (data as any).columnOrder.length ? 25 : 0,
              borderRadius: "1rem",
              backgroundImage: `url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='16' ry='16' stroke='%23333' stroke-width='2' stroke-dasharray='24' stroke-dashoffset='10' stroke-linecap='square'/%3e%3c/svg%3e")`,
              padding: "3rem",
              cursor: "pointer",
            }}
          >
            <IconContext.Provider
              value={{
                style: {
                  fontSize: "6rem",
                  color: "white",
                  opacity: ".6",
                  paddingBottom: "10px",
                },
              }}
            >
              <HiPlus />
            </IconContext.Provider>
          </Box>
        </Box>
      </Flex>
      <OutsidePlaceholder onClick={handleDeleteCard} />
    </ProjectWrapper>
  )
}
