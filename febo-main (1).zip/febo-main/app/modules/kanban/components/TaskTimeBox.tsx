import { Box, Flex, SimpleGrid } from "@chakra-ui/react"
import Currency from "app/core/components/Currency"
import { TimeInput } from "app/core/components/TimeInput"
import { useCurrentUser } from "app/core/hooks/use-current-user"
import React from "react"

type TimeBoxValues = {
  label: string
  value: number
  setValue: (number) => void
  updateValue: (number: any) => Promise<void>
}
interface Props {
  selected: string
  data: TimeBoxValues
  todayTime: number
  isActive: boolean
  backgroundColor?: string
  stopTask: () => Promise<void>
}

const editableValueKeys = ["planned", "today", "time"]

const camelCaseToSpace = (s) =>
  s.charAt(0).toUpperCase() + s.replace(/\w([A-Z]{1,})/g, " L$1").toLowerCase()

export const TaskTimeBox = ({
  selected,
  backgroundColor,
  data,
  isActive,
  stopTask,
  todayTime,
}: Props) => {
  const user = useCurrentUser()

  return (
    <SimpleGrid columns={1} gap={2} my={4}>
      <Box as="span" position="absolute" textTransform="capitalize" fontSize={10} pl={3} pt={1}>
        {data.label}
      </Box>
      <Flex p={1} backgroundColor={backgroundColor} borderRadius={12}>
        {selected === "money" ? (
          <Box mx="auto" fontSize={32}>
            <Currency currency={user?.currency || undefined}>
              {(
                Number((todayTime + (isActive ? data.value : 0)) / 1000 / 3600) *
                (user?.hourlyRate || 100)
              ).toFixed(2)}
            </Currency>
          </Box>
        ) : (
          <TimeInput
            mx="auto"
            minW={32}
            maxW="100%"
            displayTime={data.value}
            isActive={isActive}
            stopFn={stopTask}
            allowZero={selected === "planned"}
            onChange={editableValueKeys.includes(selected) ? data.setValue : undefined}
            onBlur={editableValueKeys.includes(selected) && data.updateValue}
            roundStrategy="floor"
          />
        )}
      </Flex>
    </SimpleGrid>
  )
}
export default TaskTimeBox
