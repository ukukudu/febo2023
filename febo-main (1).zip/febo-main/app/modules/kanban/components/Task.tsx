import { useMutation, useQuery } from "@blitzjs/rpc"
import { Box, Button, Collapse, Flex, SimpleGrid } from "@chakra-ui/react"
import { DateTime } from "luxon"
import { Draggable } from "react-beautiful-dnd"
import { HiCheckCircle } from "react-icons/hi"
import { ScrollElement } from "app/core/hooks/use-scroll"
import { soundWithMuteSwitch } from "app/core/lib/sound"
import { Task as TaskType } from "db"
import { useInterval } from "app/core/hooks/use-interval"
import { useGlobalTimerUpdater, useStore } from "app/core/lib/store"
import createTask from "app/tasks/mutations/create-task"
import markDoneList from "app/modules/lists/mutations/markDoneList"
import markDoneTask from "app/tasks/mutations/markDoneTask"
import getKanban from "app/modules/kanban/queries/get-kanban"
import getTaksSessions from "app/tasksessions/queries/getTaksSessions"
import createTaskSession from "app/tasksessions/mutations/createTaskSession"
import updateActiveTask from "app/users/mutations/updateActiveTask"
import { useCallback, useEffect, useState } from "react"
import styled from "@emotion/styled"
import updateTask from "app/tasks/mutations/updateTask"
// import { useMemo } from "react"
import CustomEditableInput from "./CustomEditableInput"
import TaskTimeBox from "./TaskTimeBox"
import { timeDiff } from "app/core/lib/helper"

const StartStopButton = styled(Button)`
  &:focus {
    box-shadow: none;
  }
`
// export let cache: any = {}

type TaskProps = {
  task: TaskType & { duration: number }
  list: { id: string; name: string }
  index: string
  selectedTimer: string
}

export default function Task({ task, list, index, selectedTimer }: TaskProps) {
  const {
    activeTask,
    muted,
    range,
    sessionRunning,
    sessionStartedAt,
    sessionTime,
    stopedTask,
    set: setStore,
  } = useStore((state) => state)

  const [, { refetch: refetchKanban }] = useQuery(getKanban, { range })
  const [updateTaskMutation] = useMutation(updateTask)
  const [taskSessionMutation] = useMutation(createTaskSession)
  const [markDoneTaskMutation] = useMutation(markDoneTask)
  const [createTaskMutation] = useMutation(createTask)
  const [markDoneListMutation] = useMutation(markDoneList)
  const [updateActiveTaskMutation] = useMutation(updateActiveTask)

  const updateGlobalTimers = useGlobalTimerUpdater()

  const refetch = useCallback(async () => {
    await refetchKanban()
    await updateGlobalTimers()
    // adding updateGlobalTimers to the deps would cause a infinitve loop in the browser.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refetchKanban])

  const sound = (s) => soundWithMuteSwitch(s, muted)

  const [taskSessions, { refetch: refetchTaskSessions }] = useQuery(
    getTaksSessions,
    {
      taskId: task.id,
      range: range as string,
      // startDate: DateTime.fromJSDate(new Date()).toFormat("yyyy-MM-dd"),
      // endDate: DateTime.fromJSDate(new Date()).toFormat("yyyy-MM-dd"),
    },
    { suspense: false }
  )
  const [itask, setITask] = useState(task)

  const setNewTaskData = (data) => setITask(Object.assign(itask, data))

  type TaskState = {
    running: boolean
    sessionTime: number
    startedAt: number
  }
  const [taskState, setTaskState] = useState<TaskState>({
    running: activeTask === task.id && sessionRunning,
    sessionTime: activeTask === task.id ? timeDiff(sessionStartedAt) : 0,
    startedAt: activeTask === task.id ? sessionStartedAt : 0,
  })

  const [plannedTime, setPlannedTime] = useState(
    !task?.plannedTime
      ? 0
      : activeTask === task.id && sessionRunning
      ? task.plannedTime - sessionTime
      : task.plannedTime
  )
  const [elapsedTime, setElapsedTime] = useState(task?.duration || 0 + sessionTime)

  const setSessionTime = (sessionTime) => {
    setTaskState(Object.assign({}, taskState, { sessionTime }))
    setStore((s) => ({
      ...s,
      sessionTime,
    }))
  }

  useEffect(() => {
    // recover running task
    if (activeTask === task.id && sessionStartedAt) {
      setTaskState({
        startedAt: sessionStartedAt,
        running: true,
        sessionTime: timeDiff(sessionStartedAt),
      })
    }
  }, [task])

  // useEffect(() => {
  //   setElapsedTime(task.duration || 0)
  // }, [task.duration])

  // useEffect(() => {
  //   if (runningTask && runningTask.id === task.id && runningTask.started) {
  //     setSessionTime(Date.now() - (runningTask.startedAt || timeStarted))
  //   }
  // }, [range, task, runningTask, timeStarted, sessionTime, setSessionTime])

  /// ////////////////////////////
  /// Callbacks
  /// ////////////////////////////

  const mutateTask = useCallback(
    async (payload) => {
      try {
        await updateTaskMutation({ ...payload, id: task.id })
        setNewTaskData(payload)
      } catch (error) {
        console.error("could not update task", error)
      }
    },
    [task.id, updateTaskMutation]
  )

  const startTask = useCallback(async () => {
    sound("Start")
    const now = Date.now()
    setSessionTime(0)

    setStore((s) => {
      return {
        ...s,
        activeTask: task.id,
        stopedTask: undefined,
        sessionRunnning: true,
        sessionStartedAt: now,
      }
    })

    setTaskState(Object.assign({}, taskState, { running: true, sessionTime: 0, startedAt: now }))

    await mutateTask({ timeStarted: now })
    await updateActiveTaskMutation({ start: true, id: task.id, startedAt: now })

    if (plannedTime > 0) {
      localStorage.setItem(`isPlanned_${task.id}`, JSON.stringify(true))
      localStorage.setItem(`plannedId`, task.id as any)
    }
    // playSound()

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mutateTask, task.id, setStore, plannedTime, muted])

  const addNewSession = async (duration: number) => {
    return taskSessionMutation({
      taskId: task.id,
      duration: duration,
      listName: list.name,
      taskName: task.name,
      date: DateTime.local(),
    })
  }

  const stopTask = useCallback(
    async (soundType?) => {
      if (!taskState.running) return
      soundType === "plannedSound"
        ? sound("Planned")
        : activeTask === task.id && taskState.running && sound("Stop")
      const now = Date.now()

      task.duration = activeTask === task.id ? sessionTime : timeDiff(taskState.startedAt)
      setTaskState(Object.assign({}, taskState, { running: false, sessionTime: 0 }))

      await Promise.all([
        addNewSession(task.duration),
        updateTaskMutation({
          id: task.id,
          plannedTime: Math.max((task.plannedTime || 0) - task.duration, 0),
        }),
      ])

      if (activeTask === task.id) {
        localStorage.removeItem("activeTaskInProject")
        setStore((s) => {
          return {
            ...s,
            activeTask: undefined,
            stopedTask: task.id,
          }
        })
        await updateActiveTaskMutation({ start: false })
      }

      await refetch()
      // setTotalTodayTime()
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [refetch, activeTask, task.id, setStore, elapsedTime, updateTaskMutation, taskSessionMutation]
  )
  const updatePlannedTime = useCallback(
    async (plannedTime) => {
      if (typeof plannedTime !== "number") return
      await mutateTask({ plannedTime })
      await refetch()
    },
    [mutateTask, refetch]
  )

  const markDoneTaskAndRefetch = useCallback(async () => {
    if (taskState.running) await stopTask()
    await markDoneTaskMutation({ id: task.id })
    await refetch()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [taskState.running, stopTask, markDoneTaskMutation, task.id, refetch])

  /// ////////////////////////////
  /// Effects
  /// ////////////////////////////

  // init the timer if it is set to run
  // useEffect(() => {
  //   if (taskStarted && projectId === activeTaskInProject)
  //     setStore((s) => void (s.activeTask = task.id))

  //   // init sessionTime
  //   setSessionTime(taskStarted ? Date.now() - timeStarted : 0)
  // }, [task.id, setStore, taskStarted, projectId, activeTaskInProject])

  // Stop this task if another one is started
  useEffect(() => {
    const value = localStorage.getItem(`isPlanned_${task.id}`)
    const isTaskPlanned = value ? JSON.parse(value) : false

    void stopTask()

    if (taskState.running && plannedTime === 0 && isTaskPlanned && activeTask === task.id) {
      localStorage.removeItem(`isPlanned_${task.id}`)
      // ;(async () => {
      void stopTask("plannedSound")
      // })()
    }
  }, [activeTask, plannedTime, stopTask, task.id, taskState.running])

  // Keep counters in check
  useInterval(
    () => {
      if (!taskState.running) return
      const diff = timeDiff(sessionStartedAt)
      setSessionTime(diff)
      setElapsedTime((task.duration || 0) + diff)
      if (plannedTime > 0) {
        setPlannedTime(Math.max((task.plannedTime || 0) - diff, 0))
      }
    },
    taskState.running ? 1000 : null
  )

  const createNewTask = async () => {
    await createTaskMutation({ name: "", listId: list.id } as any)
    await refetch()
  }

  useEffect(() => {
    setTimeout(async () => {
      const element: HTMLTextAreaElement | null = document.querySelector(`.textArea_${task.id}`)
      const button = element?.querySelector("button")
      if (button && task.name === "") {
        button.focus()
      }
    }, 10)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itask?.collapsed])

  const saveOpenTaskId = (isCollapsed, taskId) => {
    const getIds = localStorage.getItem("openTasks")
    const ids = getIds ? JSON.parse(getIds) : []
    if (!isCollapsed) {
      if (!ids.includes(taskId)) {
        ids.push(taskId)
        localStorage.setItem("openTasks", JSON.stringify(ids))
      }
    } else {
      if (ids.includes(taskId)) {
        const indexId = ids.indexOf(taskId)
        ids.splice(indexId, 1)
        localStorage.setItem("openTasks", JSON.stringify(ids))
      }
    }
  }

  useEffect(() => {
    const listDeleteBtn = document.querySelector(`.list_${list.id}`)
    const handleListDelete = async () => {
      if (activeTask) {
        await stopTask()
        await markDoneListMutation({ id: list.id })
        await refetch()
      }
    }
    listDeleteBtn?.addEventListener("click", handleListDelete)
    return () => {
      listDeleteBtn?.removeEventListener("click", handleListDelete)
    }
  }, [activeTask, list.id, markDoneListMutation, stopTask])

  const selectableTimers = {
    planned: {
      label: "Planned",
      value: plannedTime,
      setValue: setPlannedTime,
      updateValue: updatePlannedTime,
    },
    money: {
      label: "Money",
      value: taskState.sessionTime,
    },
    // totalTime: {
    //   label: "Total time",
    //   value: itask.ti,
    // },
    today: {
      label: range,
      value: elapsedTime,
      setValue: setElapsedTime,
      updateValue: addNewSession,
    },
    session: {
      label: "Session",
      value: taskState.sessionTime,
    },
  }

  return (
    <Draggable style={{ height: "fit-content" }} draggableId={task.id} index={index}>
      {(provided, snapshot) => (
        <Box
          borderRadius="12"
          mb={4}
          boxShadow={" rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px"}
          bg={
            snapshot.isDragging
              ? "lightgreen"
              : taskState.running
              ? "yellow.100"
              : elapsedTime > 0
              ? "#edecd8"
              : "rgb(246,250,252)"
          }
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
        >
          <Collapse
            transition={{ enter: { duration: 0.05 }, exit: { duration: 0.05 } }}
            startingHeight={55}
            in={!itask?.collapsed}
          >
            <Box color={"black"} overflow="hidden" h="100%" px={4}>
              <Flex
                alignItems="start"
                pt={4}
                px={1}
                onClick={async (e) => {
                  await mutateTask({ collapsed: !itask?.collapsed })
                  saveOpenTaskId(!itask?.collapsed, task.id)
                }}
              >
                <Box
                  fontSize={itask?.collapsed ? 16 : 20}
                  fontWeight="bold"
                  pr={2}
                  onClick={async () => {
                    await mutateTask({ collapsed: !itask?.collapsed })
                    saveOpenTaskId(!itask?.collapsed, task.id)
                  }}
                >
                  {index + 1}.
                </Box>
                <Flex
                  isTruncated={itask?.collapsed}
                  style={{
                    textOverflow: "ellipsis",
                    width: "8rem !important",
                    wordBreak: "break-word",
                  }}
                >
                  {itask?.collapsed ? (
                    <Flex
                      // w={"50%"}
                      fontSize={16}
                      fontWeight={"bold"}
                      onClick={async () => {
                        await mutateTask({ collapsed: !itask?.collapsed })
                        saveOpenTaskId(!itask?.collapsed, task.id)
                      }}
                      isTruncated
                    >
                      {itask?.name || "Untitled"}
                    </Flex>
                  ) : (
                    <Box w="full" onClick={(e) => e.stopPropagation()}>
                      <CustomEditableInput
                        key={`${task.name}${itask?.collapsed}`}
                        className={`textArea_${task.id}`}
                        defaultValue={itask?.name}
                        isTextarea
                        onBlur={async (v) => {
                          setStore((s) => void (s.isDragDisable = false))
                          if (v !== "") {
                            await mutateTask({ name: v })
                          } else {
                            await markDoneTaskMutation()
                          }
                        }}
                        onFocus={(e) => {
                          e.stopPropagation()
                        }}
                        onKeyDown={async (e: any) => {
                          if (e.key === "Enter") {
                            await createNewTask()
                            ScrollElement(800, false)
                          }
                        }}
                      />
                    </Box>
                  )}
                </Flex>
                <Box as="button" ml="auto" onClick={markDoneTaskAndRefetch} pt={2}>
                  <Box as={HiCheckCircle} w={4} h={4} color="gray.500" />
                </Box>
              </Flex>

              {!itask?.collapsed && (
                <SimpleGrid columns={1} gap={2} my={2}>
                  {selectedTimer !== "session" && (
                    <TaskTimeBox
                      isActive={taskState.running}
                      stopTask={stopTask}
                      backgroundColor={task.id === stopedTask ? "#f1f1f1" : "white"}
                      todayTime={elapsedTime || 0}
                      selected={selectedTimer}
                      data={selectableTimers[selectedTimer]}
                    />
                  )}
                  <StartStopButton
                    w="full"
                    fontSize={18}
                    borderRadius={12}
                    py={2}
                    mb={4}
                    // bg="#19012B"
                    bg={taskState.running ? "#F25C12" : "#19012B"}
                    colorScheme={taskState.running ? "#F25C12" : "#19012B"}
                    color="white"
                    onClick={taskState.running ? stopTask : startTask}
                  >
                    {taskState.running ? "STOP" : "START"}
                  </StartStopButton>
                </SimpleGrid>
              )}
            </Box>
          </Collapse>
        </Box>
      )}
    </Draggable>
  )
}
