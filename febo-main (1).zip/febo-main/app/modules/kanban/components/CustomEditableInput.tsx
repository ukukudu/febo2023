import { useParam } from "@blitzjs/next";
/* eslint-disable jsx-a11y/no-static-element-interactions */
import { ReactElement, useEffect, useRef, useState } from "react"
import { useMemo } from "react"

interface Props {
  defaultValue?: any
  onBlur: (value: string) => void
  onKeyDown?: (e: any) => void
  placeholder: string
  className?: string
  onFocus?: (e) => void
  isDisabled?: boolean
  submitOnBlur?: boolean
  fontSize?: number
  fontWeight?: string
  height?: number
  lineHeight?: number
  onSubmit?: (e) => void
  isTextarea: boolean
}

const CustomEditableInput = ({
  defaultValue,
  onBlur,
  onKeyDown,
  onFocus,
  placeholder,
  className,
  isTextarea,
}: Props): ReactElement => {
  const [value, setValue] = useState(defaultValue || placeholder)
  const [showInput, setShowInput] = useState(defaultValue === "" ? true : false)
  const inputRef = useRef<any>()

  useEffect(() => {
    if (defaultValue === "" && showInput) {
      setTimeout(() => {
        inputRef.current.focus()
      }, 100)
    }
    if (className !== "") {
      if (defaultValue !== "") {
        setValue(defaultValue)
      } else if (placeholder !== "") {
        setValue(placeholder)
      }
    }
  }, [showInput, inputRef, defaultValue, placeholder, className])

  const handlePreview = () => {
    setShowInput(true)
    setTimeout(() => {
      if (inputRef?.current?.focus) {
        inputRef.current.focus()
      }
    }, 100)
  }
  const handleFocus = (e) => {
    if (onFocus) {
      onFocus(e)
      // console.log("hhe", inputRef.current.height)
      if (isTextarea) {
        if (inputRef.current.value !== "") {
          inputRef.current.style.height = "120px"
          inputRef.current.style.overflowY = "scroll"
          const heightLimit = 1000
          inputRef.current.oninput = function () {
            // inputRef.current.style.height = inputRef.current.scrollHeight /* Reset the height*/
            inputRef.current.style.height =
              Math.min(inputRef.current.scrollHeight, heightLimit) + "px"
          }
        }
      }
      if (value === placeholder) {
        setValue("")
      }
    }
  }

  const handleKeydown = (e) => {
    if (isTextarea) {
      const heightLimit = 1000
      inputRef.current.oninput = function () {
        inputRef.current.style.height = inputRef.current.scrollHeight /* Reset the height*/
        inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, heightLimit) + "px"
      }
    }
    if (e.keyCode === 13) {
      inputRef.current.blur()
      if (onKeyDown) {
        onKeyDown(e)
      }
    }
  }

  return (
    <div>
      {showInput ? (
        isTextarea ? (
          <textarea
            style={{
              fontWeight: 700,
              overflow: "hidden",
              fontSize: 20,
              width: "100%",
              borderRadius: "10px",
              paddingLeft: "2px",
              height: "2rem",
            }}
            ref={inputRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onFocus={handleFocus}
            onBlur={() => {
              setShowInput(false)
              onBlur(value)
              if (value === "") {
                setValue(placeholder)
              }
            }}
            onKeyDown={handleKeydown}
          />
        ) : (
          <input
            style={{
              fontWeight: 700,
              fontSize: 20,
              width: "100%",
              borderRadius: "10px",
              paddingLeft: "2px",
              height: "auto",
              color: "black",
            }}
            ref={inputRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onFocus={handleFocus}
            onBlur={() => {
              setShowInput(false)
              onBlur(value)
              if (value === "") {
                setValue(placeholder)
              }
            }}
            onKeyDown={handleKeydown}
          />
        )
      ) : (
        <div
          className={className}
          style={{ cursor: "pointer", fontWeight: 700, fontSize: 20 }}
          onClick={handlePreview}
        >
          {value}
        </div>
      )}
    </div>
  )
}

CustomEditableInput.defaultProps = {
  className: "",
  onkeydown: (e) => {},
  onFocus: (e) => {},
  placeholder: "",
  isTextarea: false,
}

export default CustomEditableInput
