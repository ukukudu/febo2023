import { resolver } from "@blitzjs/rpc";
import { collect } from "collect.js"
import db, { TaskSession } from "db"
import { Prisma } from "@prisma/client"

export default resolver.pipe(resolver.authorize(), async ({ fromDate, untilDate, range }, ctx) => {
  const project = await db.project.findFirst({ where: { userId: ctx.session.userId } })

  const rawLists = await db.list.findMany({
    where: {
      userId: ctx.session.userId,
      // projectId: (id as string) ?? undefined,
      deleted: false,
      done: false,
    },
    orderBy: {
      position: "asc",
    },
    include: {
      tasks: {
        where: {
          deleted: false,
          done: false,
        },
        orderBy: {
          position: "asc",
        },
      },
    },
  })

  const now = new Date()
  const rangeInDays = {
    Month: new Date(now.getFullYear(), now.getMonth(), 1),
    Week: new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - (now.getDay() > 0 ? now.getDay() + 1 : 6)
    ),
    Today: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
  }

  const from = range ? rangeInDays[range] : fromDate ? new Date(fromDate) : now
  const until = range || !untilDate ? now : new Date(untilDate)

  const whereCondition = Prisma.sql`WHERE date BETWEEN ${from} AND ${until}
                                    AND "userId" = ${ctx.session.userId}`

  const query = Prisma.sql`SELECT "taskId",
      SUM(duration) as duration
      FROM "TaskSession"
      ${whereCondition}
      GROUP BY "taskId"
    `
  const taskSessionDurations = await db.$queryRaw<TaskSession[]>(query)

  const columns = rawLists.reduce((memo, list) => {
    return {
      ...memo,
      [list.id]: { ...list, taskIds: collect(list.tasks).pluck("id").all() },
    }
  }, {})

  const tasks = collect(rawLists)
    .pluck("tasks")
    .flatten(1)
    .all()
    .reduce((memo: object, task: any) => {
      return {
        ...memo,
        [task.id]: {
          ...task,
          duration:
            taskSessionDurations.find((s) => s.taskId.toString() === task.id.toString())
              ?.duration || 0,
        },
      }
    }, {})

  const columnOrder = collect(rawLists).pluck("id").all()

  return { tasks, columns, columnOrder, project }
})
