import { resolver } from "@blitzjs/rpc";
import { Ctx } from "blitz";
import { id } from "date-fns/locale"
import db from "db"
import * as z from "zod"
import { number } from "zod"

const UpdateActiveTask = z.object({
  start: z.boolean(),
  id: z.string().optional(),
  startedAt: z.number().optional(),
})

export default resolver.pipe(
  resolver.zod(UpdateActiveTask),
  resolver.authorize(),
  async ({ start, id, startedAt }, ctx: Ctx) => {
    if (ctx.session.userId) {
      if (start && typeof startedAt !== "number") throw new Error("startedAt was not defined.")

      const task = start ? await db.task.findUnique({ where: { id } }) : null

      await db.user.update({
        where: { id: ctx.session.userId },
        data: {
          runningTaskId: task?.id || null,
          runningTaskStartedAt: start && startedAt ? new Date(startedAt) : new Date(),
        },
      })
    }
  }
)
