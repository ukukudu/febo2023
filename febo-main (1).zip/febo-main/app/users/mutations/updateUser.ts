import { resolver } from "@blitzjs/rpc";
import { Ctx } from "blitz";
import db from "db"
import * as z from "zod"

const UpdateUser = z.object({
  name: z.string().optional(),
})

export default resolver.pipe(
  resolver.zod(UpdateUser),
  resolver.authorize(),
  async (data, ctx: Ctx) => {
    if (ctx.session.userId) {
      await db.user.update({ where: { id: ctx.session.userId }, data })
    }
  }
)
