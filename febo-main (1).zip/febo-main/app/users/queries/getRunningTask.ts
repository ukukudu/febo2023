import { Ctx, NotFoundError } from "blitz"
import db from "db"

export default async function getRunningTask({}, { session }: Ctx) {
  if (!session.userId) throw new NotFoundError()

  const u = await db.user.findFirst({
    where: { id: session.userId },
    select: {
      runningTaskId: true,
      runningTaskStartedAt: true,
    },
  })

  return {
    id: u?.runningTaskId,
    startedAt: new Date(u?.runningTaskStartedAt || 0),
  }
}
