import { useRouter } from "next/router";
import { useMutation, useQuery } from "@blitzjs/rpc";
import {
  Badge,
  Box,
  Button,
  Editable,
  EditableInput,
  EditablePreview,
  FormControl,
  FormLabel,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Stack,
  Text,
  useDisclosure,
} from "@chakra-ui/react"
import styled from "@emotion/styled"
import { Listbox } from "app/core/components/Listbox"
import { currencies } from "app/core/lib/currencies"
import { timezones } from "app/core/lib/timezones"
import { Products } from "app/modules/stripe/components/Products"
import cancelSubscriptionMutation from "app/modules/stripe/mutations/cancel-subscription"
import SubscribeMutation from "app/modules/stripe/mutations/subscribe"
// import getSubscription from "app/modules/stripe/queries/get-subscription"
import updateUserMutation from "app/users/mutations/updateUser"
import getCurrentUser from "app/users/queries/getCurrentUser"
import { ReactElement, useCallback, useEffect } from "react"
import { Suspense } from "../../core/components/Suspense"

export interface IEditUserProps {}

export function EditUser({ ...props }: IEditUserProps): ReactElement {
  const [user, { refetch }] = useQuery(getCurrentUser, null)
  // const [subscription, { refetch: refetchSubscription }] = useQuery(getSubscription, {
  //   id: user?.stripeId,
  // })
  const [updateUser] = useMutation(updateUserMutation)
  const [subscribe] = useMutation(SubscribeMutation)
  const [cancelSubscription] = useMutation(cancelSubscriptionMutation)
  const { query } = useRouter()

  const { isOpen, onOpen, onClose } = useDisclosure()

  // const updateStripeSub = useCallback(
  //   async (sessionId) => {
  //     await subscribe(sessionId)
  //     await refetchSubscription()
  //   },
  //   [refetchSubscription, subscribe]
  // )

  const openPlansModal = () => {
    onOpen()
  }

  // const cancelSub = useCallback(async () => {
  //   await cancelSubscription()
  //   await refetchSubscription()
  // }, [cancelSubscription, refetchSubscription])

  // useEffect(() => {
  //   if (query.session_id) {
  //     updateStripeSub({ sessionId: query.session_id })
  //   }
  // }, [query.session_id, updateStripeSub])

  const mutate = async (payload) => {
    await updateUser(payload)
    await refetch()
  }

  const AddListButton = styled(Button)`
    &:focus {
      box-shadow: none;
    }
  `

  return (
    <>
      <Stack spacing={6}>
        <FormControl id="name" sx={{ maxWidth: 390 }}>
          <FormLabel sx={{ fontSize: 20, mb: 0 }}>Name</FormLabel>

          <Editable
            defaultValue={String(user?.name)}
            placeholder="name"
            onSubmit={(e) => mutate({ name: e })}
            border="1px solid #E2E8F0"
            borderRadius="7px"
          >
            <EditablePreview sx={{ cursor: "pointer", p: 2 }} />
            <EditableInput sx={{ bg: "white", p: 2 }} />
          </Editable>
        </FormControl>
        <FormControl id="email" sx={{ maxWidth: 390 }}>
          <FormLabel sx={{ fontSize: 20, mb: 0 }}>Email</FormLabel>
          <Editable
            defaultValue={user?.email}
            onSubmit={(e) => mutate({ email: e })}
            fontSize={18}
            border="1px solid #E2E8F0"
            borderRadius="7px"
          >
            <EditablePreview sx={{ cursor: "pointer", p: 2 }} />
            <EditableInput sx={{ bg: "white", p: 2 }} type="email" />
          </Editable>
        </FormControl>
        <FormControl id="timezone" sx={{ maxWidth: 390 }}>
          <FormLabel sx={{ fontSize: 20, mb: 0 }}>Timezone</FormLabel>
          <Listbox
            options={timezones}
            onSelect={(v) => mutate({ timezone: v })}
            value={String(user?.timezone)}
            searchable
          />
        </FormControl>
        <FormControl id="hourlyRate" sx={{ maxWidth: 390 }}>
          <FormLabel sx={{ fontSize: 20, mb: 0 }}>Hourly Rate</FormLabel>
          <Editable
            colorScheme="brand"
            border="1px solid #E2E8F0"
            borderRadius="7px"
            fontSize={20}
            defaultValue={user?.hourlyRate ? String(user?.hourlyRate) : "0"}
            onSubmit={(e) => mutate({ hourlyRate: e })}
          >
            <EditablePreview sx={{ cursor: "pointer", p: 2 }} />
            <EditableInput sx={{ bg: "white", p: 2 }} />
          </Editable>
        </FormControl>
        <FormControl sx={{ maxWidth: 390 }}>
          <FormLabel sx={{ fontSize: 20, mb: 0 }}>Currency</FormLabel>
          <Listbox
            options={currencies}
            onSelect={(v) => mutate({ currency: v })}
            value={user?.currency || undefined}
            searchable
          />
        </FormControl>

        {/* Subscription status / change -----------------------------------*/}

        {/* <Text sx={{ fontSize: 20, mb: 0, fontWeight: "medium" }}>Subscription status</Text> */}
        {/* <Box textTransform={"capitalize"}>{subscription?.status}</Box> */}

        {/*<Box as="pre" w="800px">*/}
        {/*{JSON.stringify(subscription, null, 2)}*/}
        {/*</Box>*/}

        {/* <Box>
          Subscription status:
          <Badge
            colorScheme={["active", "trialing"].includes(subscription.status) ? "green" : "yellow"}
          >
            {subscription.status === "trialing" ? "14 days trial" : subscription.status}
          </Badge>
        </Box>

        {subscription.status !== "none" && (
          <Box>
            Subscription type:
            <Badge>{subscription?.plan?.interval}</Badge>
          </Box>
        )}

        {["active", "trialing"].includes(subscription.status) && (
          <Button colorScheme={"red"} style={{ maxWidth: "390px" }} onClick={cancelSub}>
            Cancel Subscription
          </Button>
        )}

        <Button onClick={openPlansModal} style={{ maxWidth: "390px" }}>
          Change subscription
        </Button>

        <Modal isOpen={isOpen} onClose={onClose} isCentered scrollBehavior="inside">
          <ModalOverlay />
          <ModalContent maxW={"90vw"}>
            <ModalHeader textAlign={"center"}>
              <Box>Early bird</Box>
              <Box fontSize={18} fontWeight={"normal"} color={"gray.500"}>
                discounts for solopreneurs
              </Box>
            </ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <Suspense>
                <Products />
              </Suspense>
            </ModalBody>

            <ModalFooter justifyContent="center">
              © 2021 Febo Technologies OÜ. All rights reserved
            </ModalFooter>
          </ModalContent>
        </Modal> */}
      </Stack>
    </>
  )
}
