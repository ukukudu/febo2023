import { resolver } from "@blitzjs/rpc"

import db, { TaskSession } from "db"
import { Prisma } from "@prisma/client"
import * as z from "zod"
import { NotFoundError } from "blitz"

const GetStats = z.object({
  fromDate: z.string().optional(),
  untilDate: z.string().optional(),
  range: z.string().optional(),
})

type TaskDuration = {
  duration: number
}

export default resolver.pipe(
  resolver.zod(GetStats),
  resolver.authorize(),
  async ({ fromDate, untilDate, range }, ctx) => {
    const now = new Date()

    const rangeInDays = {
      Month: new Date(now.getFullYear(), now.getMonth(), 1),
      Week: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() + 1 - (now.getDay() > 0 ? now.getDay() : 6)
      ),
      Today: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
    }

    const from = range ? rangeInDays[range] : fromDate ? new Date(fromDate) : now
    const until = range || !untilDate ? now : new Date(untilDate)

    const whereCondition = Prisma.sql`WHERE date BETWEEN ${from} AND ${until}
                                      AND "userId" = ${ctx.session.userId}`

    const query = Prisma.sql`SELECT
      SUM(duration) as duration
      FROM "TaskSession"
      ${whereCondition}
      GROUP BY "userId"
    `

    const taskSession = await db.$queryRaw<TaskDuration[]>(query)

    if (!taskSession) throw new NotFoundError()

    return taskSession[0]
  }
)
