import { resolver } from "@blitzjs/rpc"
import { NotFoundError } from "blitz"
import db, { Prisma } from "db"
import * as z from "zod"

const GetStats = z.object({
  taskId: z.string(),
  fromDate: z.string().optional(),
  untilDate: z.string().optional(),
  range: z.string().optional(),
})

type Duration = {
  duration: number
}

export default resolver.pipe(
  resolver.zod(GetStats),
  resolver.authorize(),
  async ({ taskId, fromDate, untilDate, range }, ctx) => {
    const now = new Date()

    const rangeInDays = {
      Month: new Date(now.getFullYear(), now.getMonth(), 1),
      Week: new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() - (now.getDay() > 0 ? now.getDay() + 1 : 6)
      ),
      Today: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
    }

    const from = range ? rangeInDays[range] : fromDate ? new Date(fromDate) : now
    const until = range || !untilDate ? now : new Date(untilDate)

    const rangeCondition = Prisma.sql`AND date BETWEEN ${from} AND ${until}`

    const query = Prisma.sql`SELECT SUM(duration) as duration
      FROM "Task" t, "TaskSession" s
      WHERE t."userId" = ${ctx.session.userId}
      AND t.id = ${taskId}
      AND t.deleted = false
      AND "taskId" = ${taskId}
      ${rangeCondition}
    `
    const taskSessionDuration = await db.$queryRaw<Duration>(query)

    if (!taskSessionDuration) throw new NotFoundError()

    return taskSessionDuration
  }
)
