import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const AddSession = z.object({
  taskId: z.string(),
  duration: z.number(),
  date: z.string(),
  listName: z.string(),
  taskName: z.string(),
})

export default resolver.pipe(
  resolver.authorize(),
  resolver.zod(AddSession),
  async ({ taskId, ...data }, ctx) => {
    const taskSession = await db.taskSession.create({
      data: { ...data, taskId, projectName: "default", userId: ctx.session.userId },
    })
  }
)
