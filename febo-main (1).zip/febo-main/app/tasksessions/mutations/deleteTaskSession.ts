import { resolver } from "@blitzjs/rpc";
import db, { Prisma } from "db"
import * as z from "zod"

const DeleteTask = z.object({
  id: z.string(),
})

export default resolver.pipe(
  resolver.zod(DeleteTask),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const taskSession = await db.taskSession.findFirst({
      select: { id: true },
      where: { id, userId: ctx.session.userId },
    })
    const deleteSession = await db.taskSession.delete({ where: { id: taskSession?.id } })
    return deleteSession
  }
)
