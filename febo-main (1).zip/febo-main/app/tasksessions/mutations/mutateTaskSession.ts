import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const UpdateSession = z.object({
  id: z.string(),
  duration: z.number(),
  date: z.string().optional(),
})

export default resolver.pipe(
  resolver.authorize(),
  resolver.zod(UpdateSession),
  async ({ id, ...data }, ctx) => {
    return await db.taskSession.updateMany({
      where: { id, userId: ctx.session.userId },
      data,
    })
  }
)
