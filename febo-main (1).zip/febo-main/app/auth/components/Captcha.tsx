import { PropsWithoutRef, useEffect, useState, forwardRef } from "react"
import { FormControl, FormHelperText, FormLabel } from "@chakra-ui/react"

import HCaptcha from "@hcaptcha/react-hcaptcha"
import { useFormContext } from "react-hook-form"

export interface CaptchaProps
  extends PropsWithoutRef<Omit<JSX.IntrinsicElements["input"], "size">> {
  name?: string
  label?: string
  outerProps?: PropsWithoutRef<JSX.IntrinsicElements["div"]>
}

const name = "captcha"

// const Captcha = ({ setCaptcha, outerProps }: CaptchaProps) (
const Captcha = forwardRef<HTMLInputElement, CaptchaProps>(
  ({ label, outerProps, name = "captcha", ...props }, ref) => {
    const {
      register,
      setValue,
      formState: { isSubmitting, errors },
    } = useFormContext()

    const error = !errors
      ? undefined
      : Array.isArray(errors[name])
      ? (errors[name] as any).join(", ")
      : (errors[name] as any)?.message || errors[name]
    const [checked, setChecked] = useState(false)

    // for rerendering
    let [renderCaptcha, setRenderCaptcha] = useState(true)

    useEffect(() => {
      if (error) {
        setRenderCaptcha(false)
        setTimeout(() => setRenderCaptcha(true), 100)
      }
    }, [error])

    const onError = (err) => {
      error.push(err)
    }
    const onExpire = () => {
      error.push(`Captcha expired. Please try agian`)
    }

    return `${process.env.CAPTCHA_DISABLED}` ? (
      <></>
    ) : (
      <FormControl id={name} {...outerProps} isInvalid={error}>
        {label && <FormLabel>{label}</FormLabel>}
        {renderCaptcha && (
          <HCaptcha
            ref={ref as any}
            sitekey={`${process.env.H_CAPTCHA}`}
            onVerify={(e) => {
              setValue("captcha", e)
            }}
            onError={onError}
            onExpire={onExpire}
            size="compact"
          />
        )}
        <FormHelperText color={"red.500"}>{error}</FormHelperText>
      </FormControl>
    )
  }
)

export default Captcha
