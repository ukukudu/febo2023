import useModalDialog from "app/core/components/useModalDialog"
import { useState } from "react"

const useListDeleteModal = () => {
  const { ModalDialog, onOpen } = useModalDialog()
  const [args, setArgs] = useState({})
  const openListDeleteModal = (id: number) => {
    setArgs({ id })
    onOpen()
  }
  const ListDeleteModal = ({ deleteHandler }): JSX.Element => (
    <ModalDialog
      args={args}
      title={"Delete List"}
      onConfirm={deleteHandler}
      confirmLabel={"Delete"}
    >
      Are you sure you want to delete this List?
    </ModalDialog>
  )

  return { ListDeleteModal, openListDeleteModal }
}

export default useListDeleteModal
