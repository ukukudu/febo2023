import { useToast } from "@chakra-ui/react"

const useToastTaskSessionDelete = () => {
  const toast = useToast()
  return () =>
    toast({
      title: "Task Session removed.",
      description: "Task Session was removed.",
      status: "warning",
      duration: 6000,
      isClosable: true,
    })
}

export default useToastTaskSessionDelete
