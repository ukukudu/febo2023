import { duration } from "app/core/lib/duration"
import { ReactElement } from "react"
import {
  Bar,
  BarChart as Rechart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

export interface IBarChartProps {
  data: any[]
}

export function ReportChart({ data }: IBarChartProps): ReactElement {
  return (
    <ResponsiveContainer width="100%" height="100%" minHeight="120px">
      <Rechart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="day" />
        <YAxis
          dataKey="duration"
          // domain={[0, "(dataMax)"]}
          tickFormatter={(v: number) => duration(v * 3600, "floor")}
          axisLine={false}
          orientation="right"
          tickCount={6}
          width={100}
          height={200}
          stroke="black"
          style={{ marginLeft: "-10rem" }}
        />
        <Tooltip
          formatter={(v: number) => duration(v * 3600, "floor")}
          cursor={{ fill: "transparent" }}
        />
        <Bar dataKey="duration" fill="#cc3366" barSize={120} />
      </Rechart>
    </ResponsiveContainer>
  )
}
