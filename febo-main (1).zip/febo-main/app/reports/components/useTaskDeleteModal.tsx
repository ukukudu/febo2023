import useModalDialog from "app/core/components/useModalDialog"
import { useState } from "react"

const useTaskDeleteModal = () => {
  const { ModalDialog, onOpen } = useModalDialog()
  const [args, setArgs] = useState({})
  const openTaskDeleteModal = (id: number) => {
    setArgs({ id })
    onOpen()
  }
  const TaskDeleteModal = ({ deleteHandler }): JSX.Element => (
    <ModalDialog
      args={args}
      title={"Delete task"}
      onConfirm={deleteHandler}
      confirmLabel={"Delete"}
    >
      Are you sure you want to delete this task? If task is deleted all sessions are lost.
    </ModalDialog>
  )

  return { TaskDeleteModal, openTaskDeleteModal }
}

export default useTaskDeleteModal
