import { useMutation, useQuery } from "@blitzjs/rpc"
import { Box, Flex, Table, Tbody, Td, Th, Thead, Tr, Text, Switch } from "@chakra-ui/react"
import { dateOptions } from "app/core/lib/helper"
import { duration } from "app/core/lib/duration"
import { HiX } from "react-icons/hi"
import { useCurrentUser } from "app/core/hooks/use-current-user"
import deleteList from "app/modules/lists/mutations/deleteList"
import deleteTask from "app/tasks/mutations/deleteTask"
import deleteTaskSession from "app/tasksessions/mutations/deleteTaskSession"
import getLists from "app/reports/queries/getLists"
import mutateTaskSession from "app/tasksessions/mutations/mutateTaskSession"
import { ReactElement, useEffect, useMemo, useState } from "react"
import TaskTimeBox from "app/modules/kanban/components/TaskTimeBox"
import useListDeleteModal from "./useListDeleteModal"
import useTaskDeleteModal from "./useTaskDeleteModal"
import useToastNonEmptyListDelete from "./useToastNonEmptyListDelete"
import useToastTaskSessionDelete from "./useToastTaskSessionDelete"

type TaskType = {
  id: string
  name: string
  deleted: boolean
  sum: number
  taskSession: {
    id: string
    duration: number
    date: Date
  }[]
}

type ListType = {
  id: string
  name: string
  deleted: boolean
  sum: number
  tasks: TaskType[]
}

const tdLastRow = { borderBottom: "gray dotted 1px" }

const showMoney = (user) => user?.hourlyRate! > 0 && user?.currency
const moneyTd = (duration, user, tdProps) =>
  showMoney(user) && (
    <Td style={tdProps}>
      {duration > 0 && (Number(duration / 1000 / 3600) * (user.hourlyRate || 0)).toFixed(2)}
    </Td>
  )

const DeleteButton = ({ handler, id }) => (
  <Box
    _hover={{ cursor: "pointer" }}
    onClick={() => handler(id)}
    as={HiX}
    w={4}
    h={4}
    color="gray.500"
  />
)

interface ListRowParams {
  list: ListType
  total: number
  showZeroDuration: boolean
  deleteListHandler: (string) => any
  deleteTaskHandler: (string) => any
}
const ListRow = ({
  list,
  total,
  showZeroDuration,
  deleteListHandler,
  deleteTaskHandler,
}: ListRowParams): ReactElement => {
  const [isOpen, setIsOpen] = useState(false)
  const user = useCurrentUser()
  const zero = list.sum === 0

  const collapseAble = {
    _hover: { cursor: "pointer" },
    onClick: () => list.tasks.length > 0 && setIsOpen(!isOpen),
  }

  const trStyle = {}
  return showZeroDuration || !zero ? (
    <>
      <Tr
        style={trStyle}
        textColor={zero ? "blackAlpha.600" : "black"}
        key={list.name}
        fontWeight={isOpen ? "bold" : ""}
      >
        <Td isNumeric {...collapseAble}>
          {list.tasks.filter((t) => showZeroDuration || t.sum > 0).length}
        </Td>
        <Td isNumeric {...collapseAble}>
          {Math.round((list.sum / total) * 100)}%
        </Td>
        <Td {...collapseAble}>{list.name}</Td>
        <Td isNumeric>{list.sum === 0 ? "-" : duration(list.sum)}</Td>
        {moneyTd(list.sum, user, {})}
        <Td>{!list.deleted && <DeleteButton handler={deleteListHandler} id={list.id} />}</Td>
      </Tr>
      {isOpen &&
        list.tasks
          .filter((t) => showZeroDuration || t.sum > 0)
          .sort((a, b) => b.sum - a.sum)
          .map((t, i) => {
            const isLastLine = i + 1 === list.tasks.length
            const tdProps = Object.assign({}, isLastLine ? tdLastRow : {})
            return (
              <Tr
                key={`${list.name}-${t.name}-${i}`}
                textColor={t.sum === 0 ? "blackAlpha.600" : "blackAlpha.700"}
              >
                <Td style={tdProps}></Td>
                <Td isNumeric>{Math.round((t.sum / list.sum) * 100)}%</Td>
                <Td style={tdProps}>{t.name}</Td>
                <Td isNumeric style={tdProps}>
                  {t.sum === 0 ? "-" : duration(t.sum)}
                </Td>
                {moneyTd(t.sum, user, tdProps)}
                <Td style={tdProps}>
                  {!t.deleted && <DeleteButton handler={deleteTaskHandler} id={t.id} />}
                </Td>
              </Tr>
            )
          })}
    </>
  ) : (
    <></>
  )
}

interface TasksRowProps {
  task: TaskType
  total: number
  showZeroDuration: boolean
  deleteTaskHandler: (string) => any
  updateSession: (string) => Promise<any>
  deleteSessionHandler: (string) => Promise<any>
}

const TasksRow = ({
  task,
  total,
  showZeroDuration,
  deleteTaskHandler,
  updateSession,
  deleteSessionHandler,
}: TasksRowProps): ReactElement => {
  const [isOpen, setIsOpen] = useState(false)
  const user = useCurrentUser()

  const zero = task.sum === 0
  const trStyle = {}
  const collapseAble = {
    _hover: { cursor: "pointer" },
    onClick: () => task.taskSession.length > 0 && setIsOpen(!isOpen),
  }
  return showZeroDuration || !zero ? (
    <>
      <Tr
        style={trStyle}
        textColor={zero ? "blackAlpha.600" : "black"}
        key={task.name}
        fontWeight={isOpen ? "bold" : ""}
      >
        <Td isNumeric {...collapseAble}>
          {task.taskSession.length > 0 && task.taskSession.length}
        </Td>
        <Td isNumeric {...collapseAble}>
          {Math.round((task.sum / total) * 100)}%
        </Td>
        <Td {...collapseAble}>{task.name}</Td>
        <Td isNumeric>{zero ? "-" : duration(task.sum)}</Td>
        {moneyTd(task.sum, user, {})}
        <Td>{!task.deleted && <DeleteButton handler={deleteTaskHandler} id={task.id} />}</Td>
      </Tr>
      {isOpen &&
        task.taskSession
          .sort((a, b) => b.duration - a.duration)
          .map((s, i) => {
            const isLastLine = i + 1 === task.taskSession.length
            const tdProps = isLastLine ? tdLastRow : {}
            return (
              <Tr key={`${task.name}-${s.id}-${i}`} textColor={"blackAlpha.700"}>
                <Td style={tdProps}></Td>
                <Td isNumeric>{Math.round((s.duration / task.sum) * 100)}%</Td>
                <Td style={tdProps}>{s.date.toLocaleString(undefined, dateOptions as any)}</Td>
                <Td isNumeric style={tdProps}>
                  {!!s.duration && (
                    <TaskTimeBox
                      isActive={false}
                      stopTask={async () => {}}
                      todayTime={s.duration}
                      selected={"time"}
                      data={{
                        label: "",
                        value: s.duration,
                        setValue: async (t) => {
                          console.log("set Value", t)
                        },
                        updateValue: async (t) => {
                          !!t && (await updateSession({ id: s.id, duration: t }))
                        },
                      }}
                    />
                  )}
                </Td>
                {moneyTd(s.duration, user, tdProps)}
                <Td style={tdProps}>
                  <DeleteButton handler={deleteSessionHandler} id={s.id} />
                </Td>
              </Tr>
            )
          })}
    </>
  ) : (
    <></>
  )
}

export default function ReportTable({ range, total, refetchTrigger }) {
  const user = useCurrentUser()
  const [groupSwitch, setGroupSwitch] = useState("list")
  const [showZeroDuration, setShowZeroDuration] = useState(false)
  const [lists, { refetch }] = useQuery(getLists, { ...range, groupSwitch }, { suspense: false })
  const uplist = lists?.map((list) => {
    const tasks = list.tasks.map((t) => ({
      ...t,
      sum: t.taskSession.reduce((total, s) => total + s.duration, 0),
    }))
    return {
      id: list.id,
      name: list.name,
      tasks,
      sum: tasks.reduce((total, t) => total + t.sum, 0),
    } as ListType
  })
  const [updateSessionMutation] = useMutation(mutateTaskSession)
  const [deleteListMutation] = useMutation(deleteList)
  const [deleteTaskMutation] = useMutation(deleteTask)
  const [deleteTaskSessionMutation] = useMutation(deleteTaskSession)

  const confirmedListDelete = async ({ id }) => {
    await deleteListMutation({ id })
    await refetch()
    refetchTrigger()
  }
  const confirmedTaskDelete = async ({ id }) => {
    await deleteTaskMutation({ id })
    await refetch()
    refetchTrigger()
  }

  // const { TaskDeleteModal, openTaskDeleteModal } = useTaskDeleteModal()
  const { TaskDeleteModal, openTaskDeleteModal } = useTaskDeleteModal()
  const { ListDeleteModal, openListDeleteModal } = useListDeleteModal()
  const listNotEmptyNotifiaction = useToastNonEmptyListDelete()
  const deleteTaskSessionNotification = useToastTaskSessionDelete()

  const deleteTaskHandler = (id) => {
    openTaskDeleteModal(id)
  }
  const deleteListHandler = (id) => {
    openListDeleteModal(id)
  }
  const deleteSessionHandler = async (id) => {
    const deleted = await deleteTaskSessionMutation({ id })
    deleted && deleteTaskSessionNotification()
    await refetch()
    refetchTrigger()
  }

  const updateSession = async ({ id, duration }) => {
    await updateSessionMutation({ id, duration })
    await refetch()
    refetchTrigger()
  }

  useEffect(() => {
    void refetch()
  }, [groupSwitch, refetch])

  return (
    <Flex direction={"column"} mt={4}>
      <TaskDeleteModal deleteHandler={confirmedTaskDelete} />
      <ListDeleteModal deleteHandler={confirmedListDelete} />

      <Flex direction={"row"} m={8} mb={4}>
        <Text>List</Text>
        <Switch
          mx={2}
          colorScheme="teal"
          onChange={(e) => setGroupSwitch(e.currentTarget.checked ? "task" : "list")}
        />
        <Text>Task</Text>
        <Text ml={24}>Show zero items</Text>
        <Switch
          mx={2}
          colorScheme="teal"
          checked={showZeroDuration}
          onChange={(e) => setShowZeroDuration(!!e.currentTarget.checked)}
        />
      </Flex>

      <Table m={1} borderRadius={"xl"}>
        <Thead color={"red"}>
          <Tr className="thead">
            <Th width={24}></Th>
            <Th width={24}></Th>
            <Th>
              <Text textAlign={"start"} pl={4}>
                {groupSwitch}
              </Text>
            </Th>
            <Th width={40} isNumeric>
              duration
            </Th>
            {showMoney(user) && <Th>{user?.currency}</Th>}
            <Th></Th>
          </Tr>
        </Thead>
        <Tbody>
          {uplist
            ?.sort((a, b) => b.sum - a.sum)
            .map((list) =>
              groupSwitch === "list" ? (
                <ListRow
                  key={list.id}
                  list={list}
                  total={total}
                  showZeroDuration={showZeroDuration}
                  deleteListHandler={
                    list.tasks.length > 0 ? listNotEmptyNotifiaction : deleteListHandler
                  }
                  deleteTaskHandler={deleteTaskHandler}
                />
              ) : (
                list.tasks
                  .sort((a, b) => b.sum - a.sum)
                  .map((t) => (
                    <TasksRow
                      key={t.name}
                      task={t}
                      total={total}
                      showZeroDuration={showZeroDuration}
                      deleteTaskHandler={deleteTaskHandler}
                      updateSession={updateSession}
                      deleteSessionHandler={deleteSessionHandler}
                    />
                  ))
              )
            )}
        </Tbody>
      </Table>
    </Flex>
  )
}
