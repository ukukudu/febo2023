import { useToast } from "@chakra-ui/react"

const useToastNonEmptyListDelete = () => {
  const toast = useToast()
  return () =>
    toast({
      title: "List can not be deleted.",
      description: "List is not empty and can not be deleted.",
      status: "warning",
      duration: 6000,
      isClosable: true,
    })
}

export default useToastNonEmptyListDelete
