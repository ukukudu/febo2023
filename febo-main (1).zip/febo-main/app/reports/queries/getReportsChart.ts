import { resolver } from "@blitzjs/rpc"
import { NotFoundError } from "blitz"
import db, { Prisma } from "db"
import * as z from "zod"

const GetTaskSession = z.object({
  start: z.date(),
  end: z.date(),
})

export type ChartType = {
  duration: number
  day: Date
}

export default resolver.pipe(
  resolver.zod(GetTaskSession),
  resolver.authorize(),
  async ({ start, end }, ctx) => {
    const range = {
      start,
      end: new Date(end.setDate(end.getDate() + 1)),
    }

    const query = Prisma.sql`SELECT
      SUM(duration)::float / 3600 as duration,
      to_char("date", 'FMMonth DD') as day
      FROM "List" l, "Task" t, "TaskSession" s
      WHERE l."userId" = ${ctx.session.userId} AND l.deleted = false AND l.id = t."listId"
      AND t."userId" = ${ctx.session.userId} AND t.deleted = false AND t.id = s."taskId"
      AND s.date BETWEEN ${range.start} AND ${range.end}
      AND s."userId" = ${ctx.session.userId}
      GROUP BY date
      ORDER BY date
    `
    const taskSession = await db.$queryRaw<ChartType[]>(query)

    if (!taskSession) throw new NotFoundError()

    return taskSession
  }
)
