import { resolver } from "@blitzjs/rpc"
import { NotFoundError } from "blitz"
import db from "db"
import * as z from "zod"

const GetTaskSession = z.object({
  startDate: z.date(),
  endDate: z.date(),
  groupSwitch: z.string().optional(),
  deleted: z.boolean().default(false),
})

export type ListReport = {
  name: string
  list: {
    taskName: string
    duration: number
  }
}

export default resolver.pipe(
  resolver.zod(GetTaskSession),
  resolver.authorize(),
  async ({ startDate, endDate, deleted }, ctx) => {
    const range = {
      start: startDate,
      end: new Date(endDate.setDate(endDate.getDate() + 1)),
    }

    const rawLists = await db.list.findMany({
      where: {
        userId: ctx.session.userId,
        deleted: deleted ? undefined : false,
      },
      select: {
        id: true,
        name: true,
        deleted: true,
        tasks: {
          where: {
            deleted,
          },
          select: {
            id: true,
            name: true,
            taskSession: {
              select: {
                duration: true,
                date: true,
                createdAt: true,
              },
              where: {
                date: {
                  gte: range.start,
                  lt: range.end,
                },
              },
            },
          },
        },
      },
    })

    if (!rawLists) throw new NotFoundError()
    return rawLists
  }
)
