import { resolver } from "@blitzjs/rpc"
import { NotFoundError } from "blitz"
import db, { Prisma } from "db"
import * as z from "zod"

const GetTaskSession = z.object({
  start: z.date(),
  end: z.date(),
  groupSwitch: z.string().optional(),
  deleted: z.boolean().default(false),
})

export type ListReport = {
  name: string
  list: {
    taskName: string
    duration: number
  }
}

export default resolver.pipe(
  resolver.zod(GetTaskSession),
  resolver.authorize(),
  async ({ start, end, deleted, groupSwitch = "list" }, ctx) => {
    const range = {
      start,
      end: new Date(end.setDate(end.getDate() + 1)),
    }

    const query = Prisma.sql`SELECT l.id, l.name, t.name "taskName",
        SUM(s.duration) duration
        FROM "List" l, "Task" t, "TaskSession" s
        WHERE l."userId" = ${ctx.session.userId}
        AND l."deleted" = false
        AND t."deleted" = false
        AND t."listId" = l.id
        AND s."taskId" = t.id
        AND s.date BETWEEN ${range.start} AND ${range.end}
        GROUP BY l.id, t.id
        ORDER BY s.duration, l.id
    ;`

    const rawLists = await db.list.findMany({
      where: {
        userId: ctx.session.userId,
        deleted,
      },
      select: {
        id: true,
        name: true,
        deleted: true,
        tasks: {
          where: {
            deleted,
          },
          select: {
            id: true,
            name: true,
            deleted: true,
            taskSession: {
              select: {
                id: true,
                duration: true,
                date: true,
              },
              where: {
                date: {
                  gte: range.start,
                  lt: range.end,
                },
              },
            },
          },
        },
      },
    })

    if (!rawLists) throw new NotFoundError()

    return rawLists
  }
)
