import { useEffect, useRef } from "react"
import * as workerTimers from "worker-timers"

export function useInterval(callback: any, delay: number | null): void {
  const savedCallback: any = useRef()

  // Remember the latest callback.
  useEffect(() => {
    savedCallback.current = callback
  }, [callback])

  // Set up the interval.
  useEffect(() => {
    function tick(): void {
      savedCallback.current()
    }
    if (delay !== null) {
      const id = workerTimers.setInterval(tick, delay)
      return () => workerTimers.clearInterval(id)
    }
  }, [delay])
}
