import { useQuery } from "@blitzjs/rpc";
import getCurrentUser from "app/users/queries/getCurrentUser"
import { useEffect } from "react"
// import getSubscription from "../../modules/stripe/queries/get-subscription"

export const useCurrentUser = () => {
  const [user] = useQuery(getCurrentUser, null)
  // const [subscription] = useQuery(getSubscription, {
  //   id: user?.stripeId,
  // })

  return user
}
