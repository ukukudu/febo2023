import { useRouter } from "next/router"
import { useQuery } from "@blitzjs/rpc"
import { useEffect } from "react"
import getSubscription from "../../modules/stripe/queries/get-subscription"
import { useCurrentUser } from "./use-current-user"

const fifteenMinutes = 900000
const env = process.env.APP_ENV || process.env.NODE_ENV

// forward user to account page, when no subscription
export const useSubscription = () => {
  // const router = useRouter()
  // const user = useCurrentUser()
  // const [subscription] = useQuery(
  //   getSubscription,
  //   {
  //     id: user?.stripeId,
  //   },
  //   { cacheTime: fifteenMinutes, staleTime: fifteenMinutes, refetchOnWindowFocus: false }
  // )
  // useEffect(() => {
  //   if (
  //     window.location.hostname === "febo.app" &&
  //     env === "production" &&
  //     (!subscription || !["active", "trialing"].includes(subscription?.status))
  //   ) {
  //     router.push("/account")
  //   }
  // }, [router, subscription, subscription?.status])
}
