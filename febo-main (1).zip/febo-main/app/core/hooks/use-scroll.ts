export const ScrollElement = (timeout: number, scrollHorizontal: boolean) => {
  setTimeout(() => {
    var element = document.querySelector(".scrollableContainer")
    if (element) {
      const screenSize = window.screen.availWidth
      let scrollLeft = scrollHorizontal ? element.scrollWidth : element.scrollLeft
      if (scrollHorizontal && screenSize > 320 && screenSize <= 425) {
        scrollLeft = element.scrollWidth - 500
      }

      if (scrollHorizontal && screenSize <= 320) {
        scrollLeft = element.scrollWidth - 490
      }

      element.scrollTo({
        top: scrollHorizontal ? element.scrollTop : element.scrollTop + 250,
        left: scrollLeft,
        behavior: "smooth",
      })
    }
  }, timeout)
}
