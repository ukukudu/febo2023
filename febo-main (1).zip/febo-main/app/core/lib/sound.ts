enum Sound {
  Start = "Start",
  Stop = "Stop",
  Planned = "Planned",
}

const audio = {}

if (typeof Audio !== "undefined") {
  audio["Start"] = new Audio("/sound/START_febo1.m4a")
  audio["Stop"] = new Audio("/sound/STOP_febo1.m4a")
  audio["Planned"] = new Audio("/sound/PLANNED_febo1.m4a")
}

typeof window !== "undefined" && console.log("defining sounds", Object.keys(audio), audio)

const play = (sound: Sound) => {
  // stop all other sounds
  Object.keys(audio)
    .filter((k) => (k as Sound) !== sound)
    .forEach((s) => {
      audio[s].pause()
      audio[s].currentTime = 0
    })

  console.debug("Sound play:", sound)
  audio[sound].play()
}

const noSound = (sound: Sound) => console.debug("Sound muted:", sound)

export const soundWithMuteSwitch = (sound: Sound, muted: boolean) => {
  muted ? noSound(sound) : play(sound)
}
