import { useQuery } from "@blitzjs/rpc";

/* eslint-disable no-void, no-return-assign */
import produce from "immer"
import create from "zustand"
import { devtools } from "zustand/middleware"
import { SelectableTimer, DateRange } from "types"
import { searchParams } from "./helper"
import getProjectDetails from "app/modules/projects/queries/getProjectDetails"
import { useEffect } from "react"

type State = {
  activeTask?: string
  activeTaskInProject: string | null | undefined
  excludedLists: Array<string>
  isDragDisable: boolean
  isPlanned: boolean
  logoutClicked: boolean
  muted: boolean
  plannedId: any
  plannedTime: number
  range: DateRange
  routeChange: boolean
  selectedTimer: SelectableTimer
  sessionRunning: boolean
  sessionStartedAt: number
  sessionTime: number
  stopedTask?: string
  totalTodayTime: number
}

type StateWithFn = State & { set: (fn: (draft: State) => void) => void }
const getLocalStorage =
  typeof localStorage !== "undefined" ? localStorage.getItem("activeTaskInProject") : null

export const useStore = create<StateWithFn>(
  devtools((set) => ({
    activeTaskInProject: getLocalStorage,
    excludedLists: [],
    isDragDisable: false,
    isPlanned: false,
    logoutClicked: false,
    muted: false,
    plannedId: "",
    range: searchParams()["range"] || "Today",
    routeChange: false,
    selectedTimer: "planned",
    sessionRunning: false,
    sessionStartedAt: 0,
    sessionTime: 0,
    totalTodayTime: 0,
    plannedTime: 0,
    // Set Fn
    set: (fn) => set(produce<State>(fn)),
  }))
)

export const useGlobalTimerUpdater = () => {
  const { range, plannedTime, set: setStore } = useStore((state) => state)

  const [projectDetails, { refetch }] = useQuery(getProjectDetails, { range: range as string })
  const { excludedLists } = useStore((state) => state)

  useEffect(() => {
    setStore((s) => ({
      ...s,
      plannedTime: projectDetails
        .filter((p) => {
          return !excludedLists.includes(p.listId)
        })
        .reduce((previousValue, c) => previousValue + c.plannedTime, 0),
    }))
  }, [excludedLists, plannedTime, projectDetails, setStore])

  return async () => {
    await refetch()
  }
}
