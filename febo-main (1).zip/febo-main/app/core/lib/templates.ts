export const projectTemplate = [
  "To Do | In Progress | Review | Done",
  "No Template",
  "To Do",
  "To Do | Done ",
  "To Do | In Progress | Done",
  "The Next Three Days | Done",
  "This Week | Today | Tomorrow",
  "Research | Write | Edit | Publish",
  "Business | Health | Family | Work | Dreams",
  "Upcoming | Sprint Backlog | In Progress | Done",
]
