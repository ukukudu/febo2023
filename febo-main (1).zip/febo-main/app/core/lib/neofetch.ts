/* eslint-disable guard-for-in,no-restricted-syntax */
function deepMerge(opts, overrides) {
  const out = {}
  let i
  if (Array.isArray(opts)) {
    return opts.concat(overrides)
  }
  for (i in opts) {
    out[i] = opts[i]
  }
  for (i in overrides) {
    const key = i
    const value = /** @type {any} */ overrides[i]
    out[key] = key in out && typeof value === "object" ? deepMerge(out[key], value) : value
  }
  return out
}

export type FetchUrl = string | [string, object]

export interface FetchOptions extends Omit<RequestInit, "method" | "body"> {
  method?: "GET" | "POST" | "DELETE" | "PATCH" | "PUT" | "HEAD" | "OPTIONS" | "CONNECT"
  body?:
    | Blob
    | BufferSource
    | FormData
    | URLSearchParams
    | ReadableStream<Uint8Array>
    | Object
    | string
  baseUrl?: string
  responseType?: "text" | "json" | "blob" | "arrayBuffer" | "formData" | "stream"
  paramsSerializer?: (obj: object) => string
  bearerToken?: string
}

type NeofetchFn = (url: FetchUrl, options?: FetchOptions) => Promise<any>
type NeofetchFnWithBody = (
  url: FetchUrl,
  body: FetchOptions["body"],
  options?: FetchOptions
) => Promise<any>

interface NeofetchPrototype {
  get?: NeofetchFn
  delete?: NeofetchFn
  head?: NeofetchFn
  options?: NeofetchFn
  connect?: NeofetchFn
  post?: NeofetchFnWithBody
  patch?: NeofetchFnWithBody
  put?: NeofetchFnWithBody
  defaults?: FetchOptions
}

export function createInstance(defaults: FetchOptions = {}): NeofetchFn & NeofetchPrototype {
  defaults = deepMerge(
    {
      method: "GET",
      headers: {
        Accept: "application/json, text/plain, */*",
      },
      responseType: "json",
    },
    defaults
  )

  async function redaxios(url: FetchUrl, config: FetchOptions = {}): Promise<any> {
    const options: FetchOptions = deepMerge(defaults, config)

    let uri =
      typeof url === "string" && url.includes("://") ? url : `${options.baseUrl || ""}${url}`

    if (Array.isArray(url)) {
      // eslint-disable-next-line no-bitwise
      const divider = ~url.indexOf("?") ? "&" : "?"
      const query = options.paramsSerializer
        ? options.paramsSerializer(url[1])
        : new URLSearchParams(url[1] as any)
      uri = options.baseUrl + url[0] + divider + query
    }

    if (typeof options.body === "object") {
      options.body = JSON.stringify(options.body)
      options.headers!["Content-Type"] = "application/json; charset=UTF-8"
    }

    if (options.bearerToken) {
      // @ts-ignore
      options.headers.Authorization = `Bearer ${options.bearerToken}`
    }

    const res = await fetch(uri, options as any)

    if (options.responseType === "stream") {
      return res.body
    }

    if (!res.ok) {
      const error: any = new Error("An error occurred while fetching the data.")
      // extra info to the error object.
      const errResponse = await res[options.responseType!]()
      error.response = errResponse || null

      error.status = res.status
      error.statusText = res.statusText
      error.url = uri
      throw error
    }

    let result
    try {
      result = await res[options.responseType!]()
    } catch (e) {
      result = null
    }
    return result
  }

  redaxios.get = (url, config = {}) => redaxios(url, { method: "GET", ...config })
  redaxios.delete = (url, config = {}) => redaxios(url, { method: "DELETE", ...config })
  redaxios.head = (url, config = {}) => redaxios(url, { method: "HEAD", ...config })
  redaxios.options = (url, config = {}) => redaxios(url, { method: "OPTIONS", ...config })
  redaxios.connect = (url, config = {}) => redaxios(url, { method: "CONNECT", ...config })

  redaxios.post = (url, body, config = {}) => redaxios(url, { method: "POST", body, ...config })
  redaxios.put = (url, body, config = {}) => redaxios(url, { method: "PUT", body, ...config })
  redaxios.patch = (url, body, config = {}) => redaxios(url, { method: "PATCH", body, ...config })

  redaxios.defaults = defaults

  redaxios.create = createInstance

  return redaxios
}

export const neofetch = createInstance()
