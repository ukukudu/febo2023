import { Duration } from "luxon"

export function duration(millis: number, roundStrategy = "floor") {
  if (!millis) return "0s"
  const durObject = Duration.fromMillis(Math[roundStrategy]((millis / 1000) * 1000))
    .shiftTo("hours", "minutes", "seconds")
    .toObject()

  return [
    durObject.hours > 0 && `${Math[roundStrategy](durObject.hours)}h`,
    durObject.minutes > 0 && `${Math[roundStrategy](durObject.minutes)}m`,
    `${Math[roundStrategy](durObject.seconds)}s`,
  ]
    .filter(Boolean)
    .join(" ")
}

export function toTime(millis: number, roundStrategy: "floor" | "floor" = "floor") {
  return Duration.fromMillis(Math[roundStrategy]((millis / 1000) * 1000))
    .shiftTo("hours", "minutes", "seconds")
    .toObject()
}
