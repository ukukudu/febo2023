export const searchParams = () =>
  typeof window !== "undefined" &&
  window.location.search
    .slice(1)
    .split("&")
    .reduce((acc, s) => {
      const [k, v] = s.split("=")
      return Object.assign(acc, { [k]: v })
    }, {})

export const dateOptions = {
  dateStyle: "full",
  // weekday: "long",
  // year: "numeric",
  // month: "long",
  // day: "numeric",
}

export const timeDiff = (t: number, n?: number): number => {
  const now = n || Date.now()
  return now - t - ((now - t) % 1000)
}
