import {
  Box,
  Flex,
  Input,
  InputGroup,
  InputLeftElement,
  Popover,
  PopoverBody,
  PopoverContent,
  PopoverTrigger,
  useDisclosure,
} from "@chakra-ui/react"

import { ReactElement, useState, useMemo, useCallback, useRef } from "react"
import { HiCheck, HiSearch, HiSelector } from "react-icons/hi"

type TListboxProps = {
  value?: string
  placeholder?: string
  onSelect: (value?: string) => void
  searchable?: boolean
} & (
  | { options: string[]; valueKey?: never; labelKey?: never }
  | { options: object[]; valueKey: string; labelKey: string }
)

export function Listbox({
  options,
  value,
  valueKey,
  labelKey,
  placeholder,
  onSelect,
  searchable = false,
  ...props
}: TListboxProps): ReactElement {
  const [filter, setFilter] = useState("")
  const firstFieldRef = useRef(null)
  const { onOpen, onClose, isOpen } = useDisclosure()

  if (!Array.isArray(options)) {
    throw new Error("`options` must be an array.")
  }

  const opts = useMemo(
    () =>
      // @ts-ignore We already made sure this was an array
      options.reduce((acc, option) => {
        if (typeof option === "string") return [...acc, [option, option]]

        if (!labelKey || !valueKey) {
          throw new Error(
            "When using an array of objects you must provide the `labelKey` abd the `valueKey`"
          )
        }

        return [...acc, [option[labelKey], option[valueKey]]]
      }, []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [options]
  )

  const onClick = useCallback(
    (value) => {
      onSelect(value)
      onClose()
    },
    [onClose, onSelect]
  )

  return (
    <Popover
      placement={"bottom"}
      isOpen={isOpen}
      onOpen={onOpen}
      onClose={onClose}
      initialFocusRef={firstFieldRef}
      matchWidth
    >
      <PopoverTrigger>
        <Box
          as="button"
          pos="relative"
          w="full"
          py={2}
          pl={3}
          pr={10}
          textAlign="left"
          // bg="white"
          // boxShadow="md"
          borderRadius="lg"
          border="1px solid"
          borderColor="gray.200"
          aria-haspopup="true"
        >
          <Box as="span" isTruncated>
            {value ?? placeholder ?? "Select one..."}
          </Box>
          <Flex
            as="span"
            pos="absolute"
            insetY={0}
            right={0}
            pr={2}
            alignItems="center"
            pointerEvents="none"
          >
            <Box as={HiSelector} w={5} h={5} color="gray.400" />
          </Flex>
        </Box>
      </PopoverTrigger>
      <PopoverContent _focus={{ outline: 0 }} w={"full"} maxW={"100vw"}>
        <PopoverBody p={0}>
          {searchable && (
            <Box p={4}>
              <InputGroup>
                <InputLeftElement pointerEvents="none">
                  <Box as={HiSearch} color="gray.300" />
                </InputLeftElement>
                <Input
                  ref={firstFieldRef}
                  type="text"
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                />
              </InputGroup>
            </Box>
          )}
          <Box maxH={500} overflow={"scroll"} py={2}>
            {opts
              .filter(([label]) => label.toLocaleLowerCase().includes(filter.toLowerCase()))
              .map(([label, v], index) => (
                <Flex
                  key={`option-${value}-${index}`}
                  _hover={{ bg: "orange.100", color: "orange.900" }}
                  cursor={"pointer"}
                  onClick={() => onClick(v)}
                  alignItems="center"
                  fontWeight={v === value ? "medium" : undefined}
                >
                  <Flex w={10} textAlign="center" color={v === value ? "orange.600" : undefined}>
                    {v === value && <Box m={"auto"} as={HiCheck} h={5} w={5} />}
                  </Flex>
                  <Box flex={1} py={2}>
                    {label}
                  </Box>
                </Flex>
              ))}
          </Box>
        </PopoverBody>
      </PopoverContent>
    </Popover>
  )
}

const Tmp = ({ children, ...props }) => (
  <Box
    as="button"
    pos="relative"
    w="full"
    py={2}
    pl={3}
    pr={10}
    textAlign="left"
    bg="white"
    borderRadius="lg"
    boxShadow="md"
    aria-haspopup="true"
    {...props}
  >
    <Box as="span" isTruncated>
      {children}
    </Box>
    <Flex
      as="span"
      pos="absolute"
      insetY={0}
      right={0}
      pr={2}
      alignItems="center"
      pointerEvents="none"
    >
      <Box
        as="svg"
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 20 20"
        fill="currentColor"
        w={5}
        h={5}
        color="gray.400"
        aria-hidden="true"
      >
        <path
          fillRule="evenodd"
          d="M10 3a1 1 0 01.707.293l3 3a1 1 0 01-1.414 1.414L10 5.414 7.707 7.707a1 1 0 01-1.414-1.414l3-3A1 1 0 0110 3zm-3.707 9.293a1 1 0 011.414 0L10 14.586l2.293-2.293a1 1 0 011.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
          clipRule="evenodd"
        ></path>
      </Box>
    </Flex>
  </Box>
)
// import { Box } from "@chakra-ui/layout"
// import { Button } from "@chakra-ui/button"
// import { useDisclosure } from "@chakra-ui/hooks"
// import { usePopper } from "@chakra-ui/popper"
// import { motion, AnimatePresence, Variants } from "framer-motion"

// export function Listbox() {
//   // 2. Create toggle state
//   const { isOpen, onToggle } = useDisclosure()

//   // 3. Create motion variants
//   const slide: Variants = {
//     exit: {
//       y: -2,
//       opacity: 0,
//     },
//     enter: {
//       y: 0,
//       opacity: 1,
//     },
//   }

//   // 4. Consume the `usePopper` hook
//   const { getPopperProps, getReferenceProps, getArrowProps, transformOrigin } = usePopper({
//     placement: "bottom",
//     matchWidth: true,
//   })

//   return (
//     <>
//       <Box
//         as="button"
//         {...getReferenceProps({ onClick: onToggle })}
//         w={700}
//         border="1px solid black"
//       >
//         Toggle
//       </Box>
//       <Box {...getPopperProps()} w="full">
//         <AnimatePresence>
//           {isOpen && (
//             <motion.div
//               transition={{
//                 type: "spring",
//                 duration: 0.2,
//               }}
//               variants={slide}
//               initial="exit"
//               animate="enter"
//               exit="exit"
//               style={{
//                 background: "red",
//                 transformOrigin,
//                 borderRadius: 4,
//               }}
//             >
//               Testing
//               <div
//                 {...getArrowProps({
//                   style: {
//                     background: "red.500",
//                   },
//                 })}
//               />
//             </motion.div>
//           )}
//         </AnimatePresence>
//       </Box>
//     </>
//   )
// }
