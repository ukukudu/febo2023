import { useQuery } from "@blitzjs/rpc"
import { Box, Flex } from "@chakra-ui/react"
import Currency from "app/core/components/Currency"
import { useCurrentUser } from "app/core/hooks/use-current-user"
import { duration } from "app/core/lib/duration"
import { useStore } from "app/core/lib/store"
import getProjectSessionsDuration from "app/tasksessions/queries/getProjectSessionsDuration"
import { ReactElement, useEffect } from "react"
import { Suspense } from "./Suspense"

export const TotalDuration = ({ range, sessionTime, asMoney = false }) => {
  const [projectSessionDuration, { refetch }] = useQuery(getProjectSessionsDuration, {
    range: range as string,
  })
  const user = useCurrentUser()
  const total = sessionTime || projectSessionDuration?.duration || 0

  useEffect(() => {
    if (typeof sessionTime === "undefined") {
      void refetch()
    }
  }, [sessionTime, refetch])

  return asMoney ? (
    <Currency currency={user?.currency || undefined}>
      {(Number(total / 1000 / 3600) * (user?.hourlyRate || 100)).toFixed(2)}
    </Currency>
  ) : (
    <>{duration(total)}</>
  )
}

export function GlobalSelectedTimer(props): ReactElement {
  const {
    activeTask,
    selectedTimer,
    sessionTime,
    range,
    plannedTime,
    set: setStore,
  } = useStore((state) => state)

  // Toggle between planned and today
  // const toggle = useCallback(async () => {
  //   setStore((s) => void (s.selectedTimer = selectedTimer === "today" ? "planned" : "today"))
  // }, [setStore, selectedTimer])

  return (
    <Flex
      alignItems="center"
      cursor="pointer"
      // onClick={toggle}
      {...props}
    >
      {/* <Box>{activeTask ? "counting" : selectedTimer === "today" ? range : selectedTimer}</Box> */}
      <Box>
        {
          activeTask
            ? "counting"
            : selectedTimer /** if time range is selectable: selectedTimer === "today" ? range : selectedTimer */
        }
      </Box>
      <Box ml={"0.6rem"} fontSize={17} fontWeight={"normal"}>
        <Suspense>
          {(() => {
            const props = {
              range: range,
              sessionTime: activeTask ? sessionTime : undefined,
            }

            switch (selectedTimer) {
              case "planned":
                return <>{duration(plannedTime)}</>
              case "session":
                return <>{duration(sessionTime)}</>

              // case "money":
              //   return <TotalDuration {...props} asMoney={true} />
              default:
                return <TotalDuration {...props} />
            }
          })()}
        </Suspense>
      </Box>
    </Flex>
  )
}
