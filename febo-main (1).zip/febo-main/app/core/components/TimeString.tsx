/* eslint-disable react/prop-types */
import { ReactElement } from "react"
import { Box } from "@chakra-ui/react"
import { toTime } from "../lib/duration"

export interface ITimeStringProps {
  time: number
  unstyled?: boolean
  roundStrategy?: "floor"
  [k: string]: any
}

export function TimePart({
  part,
  unit,
  unstyled = false,
  alwaysShow = false,
  ...rest
}: {
  part: number
  unit: "h" | "m" | "s"
  unstyled?: boolean
  alwaysShow?: boolean
  [k: string]: any
}) {
  if (alwaysShow || part > 0 || unit === "s") {
    return (
      <>
        <Box as="span" fontSize={unstyled ? undefined : 32} {...rest}>
          {part}
        </Box>
        <Box as="span" css={{ letterSpacing: -3, fontSize: "1rem" }}>
          {unit}
        </Box>
        {unit !== "s" ? " " : ""}
      </>
    )
  }
  return null
}

export function TimeString({
  time,
  unstyled,
  roundStrategy = "floor",
  ...props
}: ITimeStringProps): ReactElement {
  const timeObj = toTime(time)

  return (
    <Box {...props}>
      <TimePart part={Math[roundStrategy](timeObj.hours)} unit="h" unstyled={unstyled} />
      <TimePart part={Math[roundStrategy](timeObj.minutes)} unit="m" unstyled={unstyled} />
      <TimePart part={Math[roundStrategy](timeObj.seconds)} unit="s" unstyled={unstyled} />
    </Box>
  )
}
