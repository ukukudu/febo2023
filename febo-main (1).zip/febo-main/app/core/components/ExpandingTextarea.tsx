import { ComponentProps, ReactElement, useCallback, useRef } from "react"
import TextareaAutosize, { TextareaAutosizeProps } from "react-textarea-autosize"
import { Textarea } from "@chakra-ui/react"

export interface IExpandingTextareaProps {}

export type TExpandingTextareaProps = TextareaAutosizeProps & ComponentProps<typeof Textarea>

export function ExpandingTextarea({ onSubmit, ...props }: TExpandingTextareaProps): ReactElement {
  const ref = useRef<HTMLTextAreaElement>()
  const initialValue = useRef<string>()

  const onKeyPressed = useCallback((e) => {
    if (e.keyCode === 13) {
      ref.current?.blur()
    }

    if (e.keyCode === 27) {
      e.target.value = initialValue.current
      ref.current?.blur()
    }
  }, [])

  const onFocus = useCallback(
    (e) => {
      initialValue.current = e.target.value
      typeof onSubmit === "function" && onSubmit(e)
    },
    [onSubmit]
  )

  const onBlur = useCallback(
    (e) => {
      typeof onSubmit === "function" && onSubmit(e)
    },
    [onSubmit]
  )

  return (
    <>
      <Textarea
        as={TextareaAutosize}
        ref={ref as any}
        rows={1}
        resize={"none"}
        onKeyDown={onKeyPressed}
        cursor={"pointer"}
        onFocus={onFocus}
        onBlur={onBlur}
        {...props}
      />
    </>
  )
}
