import {
  FormControl,
  InputGroup,
  FormHelperText,
  FormLabel,
  Input,
  InputRightElement,
} from "@chakra-ui/react"
import { forwardRef, PropsWithoutRef } from "react"
import { useFormContext } from "react-hook-form"
// import { useState } from "react"

export interface LabeledTextFieldProps
  extends PropsWithoutRef<Omit<JSX.IntrinsicElements["input"], "size">> {
  /** Field name. */
  name: string
  /** Field label. */
  label: string
  /** Field type. Doesn't include radio buttons and checkboxes */
  type?: "text" | "password" | "email" | "number"
  icon?: any
  showPassword?: () => void
  outerProps?: PropsWithoutRef<JSX.IntrinsicElements["div"]>
}

export const LabeledTextField = forwardRef<HTMLInputElement, LabeledTextFieldProps>(
  ({ label, outerProps, name, icon, showPassword, ...props }, ref) => {
    const {
      register,
      formState: { isSubmitting, errors },
    } = useFormContext()

    const error = !errors
      ? undefined
      : Array.isArray(errors[name])
      ? (errors[name] as any).join(", ")
      : (errors[name] as any)?.message || errors[name]

    return (
      <FormControl id={name} {...outerProps} isInvalid={error}>
        <FormLabel>{label}</FormLabel>
        <InputGroup mb={-2.5}>
          <Input disabled={isSubmitting} {...register(name)} {...props} borderRadius="0" />
          <InputRightElement width="2rem" onClick={showPassword}>
            {icon}
          </InputRightElement>
        </InputGroup>
        <FormHelperText color={"red.500"}>{error}</FormHelperText>
      </FormControl>
    )
  }
)
