import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  useDisclosure,
} from "@chakra-ui/react"
import { ReactElement } from "react"

const useModalDialog = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()

  const ModalDialog = ({ title, confirmLabel, args, onConfirm, children }): ReactElement => (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{title}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>{children}</ModalBody>
        <ModalFooter>
          <Button
            onClick={async () => {
              await onConfirm(args)
              onClose()
            }}
            variant="ghost"
          >
            {confirmLabel}
          </Button>

          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  )

  return { ModalDialog, onOpen }
}

export default useModalDialog
