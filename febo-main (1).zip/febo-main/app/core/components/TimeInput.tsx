import { Box } from "@chakra-ui/react"
import { ReactElement, useRef, useState } from "react"
import { toTime } from "../lib/duration"
import { TimePart, TimeString } from "./TimeString"

export interface ITimeInputProps {
  displayTime: number
  onChange?: (number) => void
  onBlur?: any
  isActive: boolean
  stopFn: any
  roundStrategy?: "floor"
  allowZero?: boolean
  [k: string]: any
  onFocus?: (e) => void
}

export function TimeInput({
  displayTime,
  onChange = () => {},
  onBlur,
  isActive,
  stopFn,
  roundStrategy,
  onFocus,
  allowZero = false,
  ...rest
}: ITimeInputProps): ReactElement {
  const displayTimeRef: any = useRef()
  const [inputVal, setInputVal] = useState("000000")
  const [isEditable, setIsEditable] = useState(false)

  const [zeroWanted, setZeroWanted] = useState(false)
  const [backspace, setBackspace] = useState(false)

  const editTime = () => {
    if (isActive) {
      stopFn()
    }
    setInputVal("000000")
    setIsEditable(true)
    setZeroWanted(false)
    displayTimeRef.current.focus()
  }

  const getSecs = (string: string) => {
    const value = string.slice(-6).padStart(6, "0")
    const [hours, minutes, seconds] = (value as any).match(/.{1,2}/g).map((val) => val)

    const secs = +hours * 60 * 60 + +minutes * 60 + +seconds

    return secs * 1000
  }

  const trimValue = (e) => {
    if (isNaN(e.target.value)) return
    setInputVal(e.target.value.slice(-6).padStart(6, "0"))

    onChange(getSecs(e.target.value))

    if (backspace) {
      setZeroWanted(false)
      setBackspace(false)
    } else {
      setZeroWanted(Number(e.target.value) === 0)
    }
  }

  const saveValue = (e) => {
    setIsEditable(false)
    console.log("save value", e.target.value, allowZero, zeroWanted, Number(e.target.value) > 0)

    if (allowZero && zeroWanted) {
      console.log("on zero blur")
      onBlur(0)
      return
    }
    if (e.target.value && Number(e.target.value) > 0) {
      console.log("onblur save", getSecs(e.target.value), e.target.value)

      onBlur(getSecs(e.target.value))
    } else {
      console.log("fff", e.target.value)
    }
  }

  const Preview = ({ allowZero }) => {
    // const [hours, minutes, seconds] = (inputVal as any).match(/.{1,2}/g).map((val) => val)
    const time = toTime(getSecs(inputVal))
    return (
      <Box
        color="gray.200"
        fontSize={12}
        {...rest}
        style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}
      >
        <Box css={{ paddingLeft: 2.5, paddingRight: 2.5 }}>
          <TimePart
            part={time.hours}
            unit="h"
            alwaysShow
            color={time.hours > 0 ? "black" : "undefined"}
          />
        </Box>
        <Box css={{ paddingLeft: 2.5, paddingRight: 2.5 }}>
          <TimePart
            part={time.minutes}
            unit="m"
            alwaysShow
            color={time.hours > 0 || time.minutes > 0 ? "black" : undefined}
          />
        </Box>
        <Box css={{ paddingLeft: 2.5, paddingRight: 2.5 }}>
          <TimePart
            part={time.seconds}
            unit="s"
            alwaysShow
            borderRight="1px solid black"
            color={
              ((allowZero && zeroWanted && time.seconds === 0) ||
                time.hours > 0 ||
                time.minutes ||
                time.seconds) > 0
                ? "black"
                : undefined
            }
          />
        </Box>
      </Box>
    )
  }

  return (
    <>
      {isEditable ? (
        <Preview allowZero={allowZero} />
      ) : (
        <Box
          as="button"
          type="button"
          onClick={editTime}
          {...rest}
          style={{ width: "100%", margin: 0 }}
          color={displayTime <= 0 ? "gray.500" : undefined}
        >
          <TimeString time={displayTime || 0} roundStrategy={roundStrategy} />
        </Box>
      )}
      <input
        ref={displayTimeRef}
        type="text"
        value={inputVal}
        style={{
          width: 0,
          height: 0,
          opacity: 0,
          position: "absolute",
          zIndex: -2,
        }}
        onBlur={saveValue}
        onFocus={onFocus}
        onChange={trimValue}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            ;(document.activeElement as any).blur()
            return
          }
          if (e.key === "Backspace" || e.key === "Delete") {
            setZeroWanted(false)
            setBackspace(true)
          }
        }}
      />
    </>
  )
}
