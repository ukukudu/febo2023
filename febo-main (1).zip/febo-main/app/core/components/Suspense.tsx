import { ComponentProps, Suspense as ReactSuspense } from "react"
import { Flex, Spinner } from "@chakra-ui/react"

const Loader = () => (
  <Flex>
    <Spinner color="green.500" m="auto" />
  </Flex>
)

export function Suspense(props: Omit<ComponentProps<typeof ReactSuspense>, "fallback">) {
  return <ReactSuspense fallback={<Loader />} {...props} />
}
