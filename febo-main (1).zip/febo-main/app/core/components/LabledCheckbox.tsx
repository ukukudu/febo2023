import { Checkbox, FormControl, FormHelperText, FormLabel } from "@chakra-ui/react"
import { forwardRef, PropsWithoutRef, ReactNode, useState } from "react"
import { useFormContext } from "react-hook-form"

export interface LabledCheckboxProps
  extends PropsWithoutRef<Omit<JSX.IntrinsicElements["input"], "size">> {
  name: string
  label?: string
  children: ReactNode
  outerProps?: PropsWithoutRef<JSX.IntrinsicElements["div"]>
}

export const LabledCheckbox = forwardRef<HTMLInputElement, LabledCheckboxProps>(
  ({ label, outerProps, name, children, ...props }, ref) => {
    const {
      register,
      formState: { isSubmitting, errors },
    } = useFormContext()
    const error = !errors
      ? undefined
      : Array.isArray(errors[name])
      ? (errors[name] as any).join(", ")
      : (errors[name] as any)?.message || errors[name]

    const [checked, setChecked] = useState(false)

    return (
      <FormControl id={name} {...outerProps} isInvalid={error}>
        {label && <FormLabel>{label}</FormLabel>}
        <Checkbox {...register(name)} onChange={(e) => setChecked(e.target.checked)}>
          {children}
        </Checkbox>
        <FormHelperText color={"red.500"}>{error}</FormHelperText>
      </FormControl>
    )
  }
)
