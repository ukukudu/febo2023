import { PropsWithoutRef, ReactElement } from "react"

const currencySymbol = {
  EUR: "€",
  USD: "$",
  GBP: "￡",
}

interface Props {
  currency?: string
  children: ReactElement | string
}

export default function Currency({ currency, children }: Props) {
  return (
    <div>
      {currency && currencySymbol[currency.toUpperCase()]}
      {children}
    </div>
  )
}
