import { Box, Flex, Image, Stack } from "@chakra-ui/react"
import { ReactNode } from "react"

interface LayoutProps {
  children: ReactNode
}

export default function AuthLayout({ children }: LayoutProps) {
  return (
    <Stack minH={"100vh"} direction={"row"}>
      <Flex flex={1} display={{ base: "none", md: "flex" }} h={"100vh"}>
        <Image
          w={"100%"}
          alt={"Login Image"}
          objectFit={"cover"}
          // src={
          //   "https://images.unsplash.com/photo-1555212697-194d092e3b8f?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=4000&q=80"
          // }
          src="/work.png"
        />
      </Flex>
      <Flex p={8} flex={1} align={"center"} justify={"center"}>
        <Box w={2 / 3} minW={400}>
          {children}
        </Box>
      </Flex>
    </Stack>
  )
}
