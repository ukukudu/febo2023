import Link from "next/link";
import { useRouter } from "next/router"
import { useMutation } from "@blitzjs/rpc"
import { Button, Menu, MenuButton, MenuDivider, MenuItem, MenuList } from "@chakra-ui/react"
import { HiAdjustments, HiLogout, HiUserCircle } from "react-icons/hi"
import logout from "app/modules/auth/mutations/logout"
// as={Link} href={"/account"}>

const UserMenu = () => {
  const [logoutMutation] = useMutation(logout)

  const handleLogout = async () => {
    await logoutMutation()
  }
  const router = useRouter()
  return (
    <Menu>
      <MenuButton as={Button} rounded={"full"} variant={"link"} cursor={"pointer"} minW={0}>
        <HiUserCircle size="35" color="#fb738f" />
      </MenuButton>
      <MenuList>
        <MenuItem icon={<HiAdjustments />}>Account</MenuItem>
        <MenuDivider />
        <MenuItem icon={<HiLogout />} onClick={handleLogout}>
          Log out
        </MenuItem>
      </MenuList>
    </Menu>
  )
}

export default UserMenu
