import Link from "next/link"
import { useSession } from "@blitzjs/auth"
import { useRouter } from "next/router"
import {
  Box,
  Button,
  Center,
  Flex,
  Grid,
  GridItem,
  HStack,
  Text,
  Spacer,
  Switch,
  FormControl,
  FormLabel,
} from "@chakra-ui/react"
import styled from "@emotion/styled"
import { useStore } from "app/core/lib/store"
import Logo from "app/core/media/febo_logo.svg"
import { GlobalSelectedTimer } from "app/core/components/GlobalSelectedTimer"
import { ReactNode, useEffect, useState } from "react"
import { FiMail } from "react-icons/fi"
import { BsVolumeMute, BsVolumeUp } from "react-icons/bs"
import { RiBarChart2Line } from "react-icons/ri"
import UserMenu from "./UserMenu"
import { DateRange } from "types"
import { searchParams } from "../lib/helper"

const MobileMenu = styled(Flex)`
  position: sticky;
  top: 0;
  left: -2rem;
  z-index: 8;
  width: calc(100% + 4rem);
  margin-left: -2rem;
  margin-bottom: 2rem;
  padding: 2rem;
  background-color: #f6fafd;
  transform: translateY(-2rem);
  display: none;
  @media screen and (max-width: 767px) {
    display: flex;
    flex-direction: column;
    margin-bottom: 16px;
    /* margin-top: 2rem; */
  }
`
const DesktopSidebar = styled(Flex)`
  display: none;
  height: 100vh;
  @media screen and (min-width: 768px) {
    display: flex;
    flex-direction: column;
    width: 265px;
    overflow: scroll;
  }
`
const MobileSidebar = styled(Box)`
  width: 100%;
  display: none;
  position: absolute;
  left: 0;
  top: 0;
  height: 100vh;
  background-color: #000;
  z-index: 10;
  /* opacity: 0; */
  @media screen and (max-width: 767px) {
    display: block;
    ${(props) => {
      if (props.isopen) {
        return `
        transform: translateX(0);
        transition: all 0.5s;
        `
      } else {
        return `
        transform: translateX(-100%);
        transition: all 0.5s;
        `
      }
    }}
  }
`

const PlannedSessionSwitch = () => {
  const { selectedTimer, set: setStore } = useStore((state) => state)
  const setSelectedTimer = (select) => setStore((s) => void (s.selectedTimer = select))

  return (
    <FormControl display="flex" alignItems="center" color="white" w={100}>
      <FormLabel cursor="pointer" htmlFor="switchPlannedSession">
        Planned
      </FormLabel>
      <Switch
        id="switchPlannedSession"
        mx={2}
        colorScheme="orange"
        isChecked={selectedTimer == "session"}
        onChange={(e) => setSelectedTimer(selectedTimer == "planned" ? "session" : "planned")}
      />
      <FormLabel cursor="pointer" htmlFor="switchPlannedSession">
        Session
      </FormLabel>
    </FormControl>
    // </HStack>
  )
}

const Header = ({ enableSelectableRanges, children, ...props }) => {
  const { muted, selectedTimer, range, set: setStore } = useStore((state) => state)
  const setRange = (r: DateRange) => setStore((s) => void (s.range = r))

  useEffect(() => {
    const searchParamRange = searchParams()["range"]
    if (searchParamRange && searchParamRange !== range) setRange(searchParamRange)
  })

  const selectableRanges = [] //["Today", "Week", "Month"]
  let location = window.location

  const toggleMute = () => {
    setStore((s) => {
      return { ...s, muted: !muted }
    })
  }
  return (
    <Grid templateRows="repeat(2, 1fr)" templateColumns="repeat(3, 1fr)" {...props}>
      <GridItem rowSpan={2} w="100%" h="10">
        <Link href="/">
          <Box height={"100%"} as={Logo} color="gray" opacity=".9" w={100} cursor="pointer" />
        </Link>
      </GridItem>
      <GridItem rowSpan={2} h="10">
        <Center>{children}</Center>
      </GridItem>
      <GridItem>
        <HStack spacing="24px" zIndex={1000}>
          <Spacer />
          {/* <Menu>
            <MenuButton as={Button} textTransform={"capitalize"} rightIcon={<HiChevronDown />}>
              {selectedTimer}
            </MenuButton>
            <MenuList>
              <MenuItem onClick={() => setSelectedTimer("planned")}>Planned</MenuItem>
              <MenuItem onClick={() => setSelectedTimer("today")}>Today</MenuItem>
              <MenuItem onClick={() => setSelectedTimer("money")}>Money</MenuItem>
            </MenuList>
          </Menu> */}
          <Button leftIcon={<RiBarChart2Line />}>
            <Link href="/reports">Reports</Link>
          </Button>
          <Button leftIcon={<FiMail />}>
            <Link href="mailto:support@febo.app">Support</Link>
          </Button>

          <Box top="300" right="20">
            <UserMenu />
          </Box>
          <Box top="300" right="20" color="white" opacity=".9">
            <button onClick={toggleMute}>
              {muted ? <BsVolumeMute size="24" /> : <BsVolumeUp size="24" />}
            </button>
          </Box>
        </HStack>
      </GridItem>
      <GridItem>
        <HStack p={2} spacing="30px" zIndex={1000}>
          {enableSelectableRanges &&
            selectedTimer !== "planned" &&
            selectableRanges.map((r) => (
              // <Link key={r} onClick={() => setRange(r as DateRange)}>
              <Link
                key={r}
                // href={`location.pathname ${Object.assign({}, location.search { search: { range: r } })}`}
                href={`${location.pathname}?range=${r}`}
                // d={() => setRange(r as DateRange)}
              >
                <Text fontSize={18} fontWeight="bold" color={range === r ? "white" : "grey"}>
                  {r}
                </Text>
              </Link>
            ))}
        </HStack>

        <PlannedSessionSwitch />
      </GridItem>
    </Grid>
  )
}

type LayoutProps = {
  header: ReactNode | string
  bgImageOn?: boolean
  children: ReactNode
  enableSelectableRanges?: boolean
  headerMargin?: number
}

const Layout = ({ bgImageOn, enableSelectableRanges, header, children, ...props }: LayoutProps) => {
  const routes = useRouter()
  const session = useSession()

  const [collpsedSidebar, setCollpsedSidebar] = useState(false)
  const handleSidebar = () => {
    setCollpsedSidebar(!collpsedSidebar)
  }
  const backgroundProps = bgImageOn ? { backgroundImage: "url(/bg.png)" } : {}

  return (
    <Flex h={"100vh"}>
      <Box
        sx={backgroundProps}
        backgroundSize={"cover"}
        backgroundPosition={"center center"}
        flex={1}
        className="scrollableContainer"
        p={6}
        overflow={"scroll"}
      >
        <MobileMenu>
          <Box as={Logo} w={100} mb={4} mr={4} cursor="pointer" onClick={handleSidebar} />
          {routes.pathname === "/projects/[projectId]" && <GlobalSelectedTimer />}
        </MobileMenu>
        <Header
          enableSelectableRanges={enableSelectableRanges}
          as="nav"
          align="center"
          justify="space-between"
          wrap="wrap"
          position="fixed"
          w="100%"
          left="0px"
          px="2rem"
          // bg={["primary.500", "primary.500", "transparent", "transparent"]}
          // color={["white", "white", "primary.700", "primary.700"]}
          mb={props.headerMargin || 16}
        >
          <Box
            opacity=".85"
            color="white"
            textTransform="uppercase"
            fontSize={20}
            fontWeight="bold"
            marginRight="0.5rem"
          >
            {header}
          </Box>
        </Header>
        <Box mt={125}>{children}</Box>
        <Box
          backgroundImage={"url(/logo.png)"}
          backgroundSize={"cover"}
          backgroundPosition={"center center"}
          onClick={handleSidebar}
          color="white"
          w={150}
          h={98}
          // mb={4}
          pos="absolute"
          bottom="10"
          right="20"
        />
      </Box>
    </Flex>
  )
}

export default Layout
