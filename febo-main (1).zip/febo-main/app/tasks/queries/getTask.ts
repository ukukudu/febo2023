import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const GetList = z.object({
  id: z.string(),
})

export default resolver.pipe(resolver.zod(GetList), resolver.authorize(), async ({ id }, ctx) => {
  try {
    const task = await db.task.findFirst({
      where: { id, userId: ctx.session.userId },
    })
    return task
  } catch (err) {
    console.error(err)
  }
})
