import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const CreateList = z
  .object({
    name: z.string(),
    listId: z.string(),
  })
  .nonstrict()

export default resolver.pipe(resolver.zod(CreateList), resolver.authorize(), async (input, ctx) => {
  const count = await db.task.count({
    where: {
      userId: ctx.session.userId,
      listId: input.listId,
    },
  })
  const task = await db.task.create({
    data: { ...input, position: count, userId: ctx.session.userId } as any,
  })

  return task
})
