import { resolver } from "@blitzjs/rpc";
import db from "db"
import * as z from "zod"

const UpdateTask = z.object({
  id: z.string(),
  name: z.string().optional(),
  todayTime: z.number().optional(),
  plannedTime: z.number().optional(),
  collapsed: z.boolean().optional(),
})

export default resolver.pipe(
  resolver.authorize(),
  resolver.zod(UpdateTask),
  async ({ id, ...data }, ctx) => {
    const task: any = await db.task.update({ where: { id }, data })
    return task
  }
)
