import { resolver } from "@blitzjs/rpc";
import db, { Prisma } from "db"
import * as z from "zod"

const DeleteTask = z.object({
  id: z.string(),
})

export default resolver.pipe(
  resolver.zod(DeleteTask),
  resolver.authorize(),
  async ({ id }, ctx) => {
    const task = await db.task.findFirst({ where: { id, userId: ctx.session.userId } })
    const updateTask = await db.task.update({ where: { id }, data: { done: true } })
    return updateTask
  }
)
