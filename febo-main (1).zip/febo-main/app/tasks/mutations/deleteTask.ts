import { resolver } from "@blitzjs/rpc";
import db, { Prisma } from "db"
import * as z from "zod"

const DeleteTask = z.object({
  id: z.string(),
  hard: z.boolean().default(false),
})

export default resolver.pipe(
  resolver.zod(DeleteTask),
  resolver.authorize(),
  async ({ id, hard }) => {
    const task = await (hard
      ? db.$queryRaw(Prisma.sql`DELETE FROM "Task" WHERE id=${id}`)
      : db.task.delete({ where: { id } }))
    return task
  }
)
