const helmet = require("helmet")
const { Middleware, sessionMiddleware, simpleRolesIsAuthorized } = require("blitz")
const { withBlitz } = require("@blitzjs/next")

process.on("unhandledRejection", (error, p) => {
  console.log("=== UNHANDLED REJECTION ===")
  console.dir(error.stack)
})

const self = `'self'`
const hcaptcha = ["https://hcaptcha.com", "https://*.hcaptcha.com"]
const frames = ["https://febo.app", "https://*.febo.app"]

const hlmt = helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: [self],
    scriptSrc: [self, ...hcaptcha],
    styleSrc: [self, "unsafe-inline", ...hcaptcha],
    frameSrc: [self, ...frames, ...hcaptcha],
    connectSrc: [self, ...hcaptcha],
  },
})

const config = {
  env: {
    APP_ENV: process.env.APP_ENV,
    TITLE: "Febo time manager",
    ADMINPATH: "/fb-admin",
    CAPTCHA_DISABLED:
      process.env.CAPTCHA_DISABLED === true || process.env.CAPTCHA_DISABLED == "true",
    H_CAPTCHA: "8591ab93-ff41-4aee-9205-39242eb26cf7",
    H_CAPTCHA_URL: "https://hcaptcha.com/siteverify",
    CONTACT_MAIL: "support@febo.app",
  },
  images: {
    domains: [],
  },

  middleware: [
    hlmt,
    // sessionMiddleware({
    //   cookiePrefix: "__safeNameSlug__",
    //   isAuthorized: simpleRolesIsAuthorized,
    // }),
  ],
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    config.resolve.fallback = {
      ...config.resolve.fallback,
    }
    config.module.rules.push({
      test: /\.svg$/,
      use: [
        {
          loader: "@svgr/webpack",
          options: {
            dimensions: false,
          },
        },
      ],
    })
    return config
  },
}
module.exports = withBlitz(config)
