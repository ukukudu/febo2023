import SuperJson from "superjson"

export class CaptchaError extends Error {
  name = "CaptchaError"
  constructor({ message }) {
    super()
    this.message = message
  }
}

// Register with SuperJson serializer so it's reconstructed on the client
SuperJson.registerClass(CaptchaError)
SuperJson.allowErrorProps("message")
