import { useRouter } from "next/router"
import { useQuery } from "@blitzjs/rpc"
import {
  Box,
  Button,
  Flex,
  Popover,
  PopoverContent,
  PopoverTrigger,
  Text,
  useDisclosure,
  VStack,
} from "@chakra-ui/react"
import { collect } from "collect.js"
import { dateOptions } from "app/core/lib/helper"
import { duration } from "app/core/lib/duration"
import { ReportChart } from "app/reports/components/ReportChart"
import { useCurrentUser } from "app/core/hooks/use-current-user"
import { useSubscription } from "app/core/hooks/use-subscription"
import getReportsChart from "app/reports/queries/getReportsChart"
import Layout from "app/core/layouts/Layout"
import { useCallback, useEffect, useMemo, useState } from "react"
import ReportTable from "app/reports/components/ReportTable"

import {
  add,
  sub,
  startOfToday,
  startOfYesterday,
  endOfYesterday,
  previousMonday,
  nextSunday,
  startOfMonth,
  endOfMonth,
  endOfToday,
} from "date-fns"

import {
  Calendar,
  CalendarControls,
  CalendarDays,
  CalendarDefaultTheme,
  CalendarMonth,
  CalendarMonthName,
  CalendarMonths,
  CalendarNextButton,
  CalendarPrevButton,
  CalendarWeek,
} from "@uselessdev/datepicker"
import { ChakraProvider } from "@chakra-ui/react"

const Header = ({ time }) => {
  return (
    <Flex alignItems="center" cursor="pointer" color={"black"}>
      <Box>Reports</Box>
      <Box ml={"0.6rem"} fontSize={17} fontWeight={"normal"}>
        {duration(time)}
      </Box>
    </Flex>
  )
}

const DateRangeSelector = ({ selectionRange, setSelectionRange }) => {
  const { onOpen, onClose, isOpen } = useDisclosure()
  const router = useRouter()

  const handleSelectDate = (values) => () => {
    console.log("llll", values)
    setSelectionRange(values)
  }
  const today = new Date()

  const [selectedRange, setSelectedRange] = useState("Day")

  const selectToday = () => {
    setSelectedRange("Day")
    setSelectionRange({
      start: today,
      end: today,
    })
  }

  const selectYesterday = () => {
    setSelectedRange("Day")
    setSelectionRange({
      start: startOfYesterday(),
      end: endOfYesterday(),
    })
  }

  const selectThisWeek = () => {
    setSelectedRange("Week")
    setSelectionRange({
      start: previousMonday(today),
      end: nextSunday(today),
    })
  }
  const selectThisMonth = () => {
    setSelectedRange("Month")

    setSelectionRange({
      start: startOfMonth(today),
      end: endOfMonth(today),
    })
  }

  const selectDeltaFromSelectedRange = (method: "previous" | "next") => {
    const m = method === "previous" ? sub : add
    let start = selectionRange.start,
      end = selectionRange.end
    switch (selectedRange) {
      case "Week":
        start = m(start, { weeks: 1 })
        end = m(end, { weeks: 1 })
        break
      case "Month":
        start = m(start, { months: 1 })
        end = endOfMonth(m(end, { months: 1 }))
        break

      default:
        start = m(start, { days: 1 })
        end = m(end, { days: 1 })
        break
    }
    setSelectionRange({
      start,
      end,
    })
  }

  // const selectNextFromSelectedRange = () =>
  //   setSelectionRange({
  //     start: previousMonday(add(selectionRange.start, { weeks: 1 })),
  //     end: nextSunday(add(selectionRange.start, { weeks: 1 })),
  //   })

  const handleRouteRange = useCallback(
    async (r) => {
      const range = `${r.start.toLocaleDateString()}|${r.end.toLocaleDateString()}`
      await router.push(`${location.pathname}?range=${range}`, undefined, { shallow: true })
    },
    [router]
  )

  useEffect(() => {
    const element = document.querySelector(".scrollableContainer")
    if (element) {
      setTimeout(() => {
        if (isOpen) {
          ;(element as any).style.overflowX = "auto"
        } else {
          ;(element as any).style.overflowX = "hidden"
        }
      }, 100)
    }
  }, [isOpen])

  return (
    <Flex position="relative" alignItems="center" mb={16}>
      <Button
        borderTopRightRadius={0}
        borderBottomRightRadius={0}
        onClick={() => selectDeltaFromSelectedRange("previous")}
      >
        ←
      </Button>
      <Popover isOpen={isOpen} onOpen={onOpen} onClose={onClose} placement="bottom-start">
        <PopoverTrigger>
          <Button borderRadius={0}>
            {selectionRange.start.toLocaleDateString(undefined, dateOptions as any)}
            <Text mx={4} textColor={"gray"}>{` until `}</Text>
            {selectionRange.end.toLocaleString(undefined, dateOptions as any)}
          </Button>
        </PopoverTrigger>
        <PopoverContent w="fit-content">
          <Calendar
            value={selectionRange}
            onSelectDate={handleSelectDate}
            months={2}
            weekStartsOn={1}
            disableFutureDates
          >
            <Box position="relative">
              <CalendarControls>
                <CalendarPrevButton />
                <CalendarNextButton />
              </CalendarControls>

              <CalendarMonths>
                {[0, 1].map((month) => (
                  <CalendarMonth month={month} key={month}>
                    <CalendarMonthName />
                    <CalendarWeek />
                    <CalendarDays />
                  </CalendarMonth>
                ))}
              </CalendarMonths>
            </Box>
            <VStack
              spacing={4}
              bgColor="gray.50"
              p={4}
              alignItems="stretch"
              borderEndRadius="md"
              flex={1}
            >
              <Button onClick={selectToday} size="xs">
                Today
              </Button>
              <Button onClick={selectYesterday} size="xs">
                Yesterday
              </Button>
              <Button onClick={selectThisWeek} size="xs">
                This week
              </Button>

              <Button onClick={selectThisMonth} size="xs">
                This Month
              </Button>

              <Button onClick={() => selectDeltaFromSelectedRange("previous")} size="xs">
                Previous {selectedRange}
              </Button>

              <Button onClick={() => selectDeltaFromSelectedRange("next")} size="xs">
                Next {selectedRange}
              </Button>
            </VStack>
          </Calendar>
        </PopoverContent>
      </Popover>
      <Button
        borderTopLeftRadius={0}
        borderBottomLeftRadius={0}
        onClick={() => selectDeltaFromSelectedRange("next")}
      >
        →
      </Button>
    </Flex>
  )
}

export default function Reports() {
  useSubscription()
  const user = useCurrentUser()

  const now = new Date(new Date().setHours(0, 0, 0, 0))
  const someDateLater = new Date(new Date().setHours(0, 0, 0, 0))

  const query = useRouter().query
  const [selectionRange, setSelectionRange] = useState({
    start: query.range ? new Date((query.range as String).split("|")[0]) : startOfToday(),
    end: query.range ? new Date((query.range as String).split("|")[1]) : endOfToday(),
  })

  const [chartData, { refetch }] = useQuery(
    getReportsChart,
    {
      start: selectionRange.start,
      end: selectionRange.end,
    },
    { suspense: false }
  )

  const total = useMemo(() => {
    return (collect(chartData).sum("duration") as number) * 3600
  }, [chartData])

  useEffect(() => {
    if (selectionRange.start && selectionRange.end) {
      void refetch()
    }
  }, [refetch, selectionRange.start, selectionRange.end])

  return (
    <Layout headerMargin={4} header={<Header time={total} />}>
      <Box alignContent={"center"} mx={"auto"} height={"25%"} width={"90%"}>
        <ChakraProvider theme={CalendarDefaultTheme}>
          <DateRangeSelector
            selectionRange={selectionRange}
            setSelectionRange={setSelectionRange}
          />
        </ChakraProvider>
        <Box height={"45%"}>
          <ReportChart data={chartData as any} />
        </Box>
        <ReportTable range={selectionRange} total={total} refetchTrigger={refetch} />
      </Box>
    </Layout>
  )
}
