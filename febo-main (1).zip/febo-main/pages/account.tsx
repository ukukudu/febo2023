import { Box, Heading } from "@chakra-ui/react"
import { Suspense } from "app/core/components/Suspense"
import Layout from "app/core/layouts/Layout"
import { EditUser } from "app/users/components/EditUser"
import { ReactElement } from "react"

export default function Account(): ReactElement {
  return (
    <Layout header={<Box color={"black"}>Account settings</Box>}>
      <Suspense>
        <EditUser />
      </Suspense>
    </Layout>
  )
}
