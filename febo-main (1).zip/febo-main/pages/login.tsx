import { BlitzPage } from "@blitzjs/next"
import { useRouter } from "next/router"
import LoginForm from "app/modules/auth/components/LoginForm"
import React from "react"
import AuthLayout from "app/core/layouts/AuthLayout"

const LoginPage: BlitzPage = () => {
  const router = useRouter()

  return (
    <AuthLayout>
      <LoginForm
        onSuccess={async () => {
          const next = router.query.next ? decodeURIComponent(router.query.next as string) : "/"
          await router.push(next)
        }}
      />
    </AuthLayout>
  )
}

LoginPage.redirectAuthenticatedTo = "/"

export default LoginPage
