import { withBlitz } from "app/blitz-client"
import { AuthenticationError, AuthorizationError } from "blitz"
import { useRouter } from "next/router"
import { useQueryErrorResetBoundary } from "@blitzjs/rpc"

import { AppProps, ErrorBoundary, ErrorComponent, ErrorFallbackProps } from "@blitzjs/next"

import LoginForm from "app/modules/auth/components/LoginForm"
import { ChakraProvider } from "@chakra-ui/react"
import AuthLayout from "app/core/layouts/AuthLayout"
import theme from "integrations/theme/site.theme"
import { Suspense } from "react"

const env = process.env.APP_ENV || process.env.NODE_ENV

export default withBlitz(function App({ Component, pageProps }: AppProps) {
  const getLayout = Component.getLayout || ((page) => page)
  const router = useRouter()

  return (
    <Suspense fallback={<div>loading...</div>}>
      <ChakraProvider theme={theme}>
        <ErrorBoundary
          FallbackComponent={RootErrorFallback}
          resetKeys={[router.asPath]}
          onReset={useQueryErrorResetBoundary().reset}
        >
          {getLayout(<Component {...pageProps} />)}
        </ErrorBoundary>
      </ChakraProvider>
    </Suspense>
  )
})

function RootErrorFallback({ error, resetErrorBoundary }: ErrorFallbackProps) {
  if (error instanceof AuthenticationError) {
    return (
      <AuthLayout>
        <LoginForm onSuccess={resetErrorBoundary} />
      </AuthLayout>
    )
  }
  if (error instanceof AuthorizationError) {
    return (
      <ErrorComponent
        statusCode={error.statusCode}
        title="Sorry, you are not authorized to access this"
      />
    )
  }
  return <ErrorComponent statusCode={error.statusCode || 400} title={error.message || error.name} />
}
