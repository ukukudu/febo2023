import { BlitzPage } from "@blitzjs/next"
import { Suspense } from "react"
import Layout from "app/core/layouts/Layout"
import { Project } from "app/modules/kanban/components/Project"
import { useSubscription } from "app/core/hooks/use-subscription"

const ShowProjectPage: BlitzPage = () => {
  useSubscription()
  return (
    <Layout header="">
      <Suspense fallback={<div>Loading...</div>}>
        <Project />
      </Suspense>
    </Layout>
  )
}

ShowProjectPage.authenticate = true

export default ShowProjectPage
