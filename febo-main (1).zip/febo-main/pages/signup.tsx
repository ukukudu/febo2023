import { BlitzPage, Routes } from "@blitzjs/next";
import { useRouter } from "next/router";
// import Layout from "app/core/layouts/Layout"
import SignupForm from "app/modules/auth/components/SignupForm"
import { Flex } from "@chakra-ui/react"
import { AiOutlineCopyrightCircle } from "react-icons/ai"
// import AuthLayout from "app/core/layouts/AuthLayout"

const SignupPage: BlitzPage = () => {
  const router = useRouter()

  return (
    <Flex bg="#F8FBFD" h="100vh" direction="column" my="auto" pt="2rem">
      <SignupForm onSuccess={() => router.push(Routes.Index())} />
      <Flex mb="auto" mx="auto" px={8}>
        <AiOutlineCopyrightCircle style={{ marginTop: "4px", marginRight: "4px" }} /> 2021 Febo
        Technologies OÜ. All rights reserved
      </Flex>
    </Flex>
  )
}
SignupPage.redirectAuthenticatedTo = "/"

export default SignupPage
