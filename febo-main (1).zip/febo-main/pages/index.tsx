import Head from "next/head"
import { Flex } from "@chakra-ui/react"
import { GlobalSelectedTimer } from "app/core/components/GlobalSelectedTimer"
import Layout from "app/core/layouts/Layout"
import { Project } from "app/modules/kanban/components/Project"
import { ReactElement, Suspense } from "react"
import { useSubscription } from "app/core/hooks/use-subscription"

export function Index(): ReactElement {
  useSubscription()

  return (
    <Layout header={<GlobalSelectedTimer />} enableSelectableRanges={true} bgImageOn={true}>
      <Head>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Flex h="100%" maxH="100vh" direction={"column"}>
        <Suspense fallback={<div>Loading...</div>}>
          <Project />
        </Suspense>
      </Flex>
    </Layout>
  )
}

Index.suppressFirstRenderFlicker = true
Index.authenticate = true

export default Index
