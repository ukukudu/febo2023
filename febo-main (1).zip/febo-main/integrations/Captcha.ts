import { CaptchaError } from "app/auth/CaptchaError"
import axios from "axios"
import url from "url"

const env = process.env.APP_ENV || process.env.NODE_ENV
const captchaUrl = `${process.env.H_CAPTCHA_URL}`
const captchaSecret = `${process.env.H_CAPTCHA_SECRET}`

export async function verifyCaptcha(token) {
  if (process.env.CAPTCHA_DISABLED || env !== "test") {
    return
  }

  try {
    const response = await axios.post(
      captchaUrl,
      new url.URLSearchParams({ secret: captchaSecret, response: token })
    )

    if (response && response.status === 200 && response.data && response.data.success === true) {
      return false
    } else {
      throw new CaptchaError({ message: "Error resolving Captcha, please try again." })
    }
  } catch (err) {
    console.error(err)
    throw new CaptchaError({ message: "Error resolving Captcha, please try again." })
  }
}
