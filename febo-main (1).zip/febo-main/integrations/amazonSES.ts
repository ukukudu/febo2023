import nodemailer from "nodemailer"
import * as aws from "@aws-sdk/client-ses"

const sesParams = new aws.SES({
  apiVersion: "2010-12-01",
  // region: process.env.AWS_REGION,
})

export const ses = nodemailer.createTransport({
  SES: { ses: sesParams, aws },
})
