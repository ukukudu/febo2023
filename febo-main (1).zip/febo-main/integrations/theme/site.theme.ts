import { extendTheme } from "@chakra-ui/react"
// 2. Call `extendTheme` and pass your custom values
import { createBreakpoints } from "@chakra-ui/theme-tools"
// 2. Update the breakpoints as key-value pairs
const breakpoints = createBreakpoints({
  sm: "320px",
  md: "768px",
  lg: "960px",
  xl: "1200px",
})

export default extendTheme({
  colors: {
    brand: {
      100: "#f7fafc",
      // ...
      900: "#1a202c",
    },
  },
  breakpoints,

  styles: {
    // class: {
    //   thead: {
    //     bg: "red",
    //   },
    // },
    global: {
      body: {
        bg: "white",
        color: "black",
      },
      th: {
        background: "rgba(239, 226, 229, 1)",
      },
      tr: {
        background: "#f6dde5",
        _hover: {
          background: "#e699b2",
        },
        _even: {
          background: "#eebbcc",
          _hover: {
            background: "#e699b2",
          },
        },
      },
    },
  },
})
