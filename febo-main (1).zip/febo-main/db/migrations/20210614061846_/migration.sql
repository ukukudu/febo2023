-- AlterTable
ALTER TABLE "tasks" ADD COLUMN     "collapsed" BOOLEAN NOT NULL DEFAULT false;
