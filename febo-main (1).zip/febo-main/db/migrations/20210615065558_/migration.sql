-- AlterTable
ALTER TABLE "users" ADD COLUMN     "template" INTEGER NOT NULL DEFAULT 0;
