/*
  Warnings:

  - A unique constraint covering the columns `[task_id]` on the table `stats` will be added. If there are existing duplicate values, this will fail.
  - Made the column `task_id` on table `stats` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "stats" ALTER COLUMN "task_id" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "stats.task_id_unique" ON "stats"("task_id");
