-- CreateTable
CREATE TABLE "TaskSession" (
    "id" TEXT NOT NULL,
    "projectName" TEXT NOT NULL,
    "listName" TEXT NOT NULL,
    "taskName" TEXT NOT NULL,
    "duration" INTEGER NOT NULL,
    "date" DATE NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "taskId" TEXT NOT NULL,
    "userId" TEXT,

    CONSTRAINT "TaskSession_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "TaskSession" ADD CONSTRAINT "TaskSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
