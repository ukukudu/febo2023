-- DropIndex
DROP INDEX "stats.task_id_unique";
