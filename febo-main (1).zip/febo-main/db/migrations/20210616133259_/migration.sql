-- AlterTable
ALTER TABLE "users" ADD COLUMN     "stripe_subscription_id" TEXT;
