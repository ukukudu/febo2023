-- AlterTable
ALTER TABLE "users" ALTER COLUMN "name" DROP NOT NULL;
