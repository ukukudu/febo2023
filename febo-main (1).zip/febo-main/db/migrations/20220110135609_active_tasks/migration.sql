-- AlterTable
ALTER TABLE "User" ADD COLUMN     "runningTaskId" TEXT,
ADD COLUMN     "runningTaskStartedAt" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_runningTaskId_fkey" FOREIGN KEY ("runningTaskId") REFERENCES "Task"("id") ON DELETE SET NULL ON UPDATE CASCADE;
