import { enhancePrisma } from "blitz"
import { PrismaClient } from "@prisma/client"

const EnhancedPrisma = enhancePrisma(PrismaClient)
const prisma = new EnhancedPrisma({})

/***********************************/
/* SOFT DELETE MIDDLEWARE */
/* Soft Delete for Tasks and Lists
/* (will update instead fo delete)
/***********************************/
prisma.$use(async (params, next) => {
  if (params.model === "Task" || params.model === "List") {
    // deleted could be changed DateTime
    // If you need to set the value of a DateTime field, can you use the now() function or the @updatedAt attribute?

    if (params.action == "delete") {
      // Delete queries
      // Change action to an update
      params.action = "update"
      params.args["data"] = { deleted: true }
    }
    if (params.action == "deleteMany") {
      // Delete many queries
      params.action = "updateMany"
      if (params.args.data != undefined) {
        params.args.data["deleted"] = true
      } else {
        params.args["data"] = { deleted: true }
      }
    }

    // if (params.action === "done") {
    //   // Delete queries
    //   // Change action to an update
    //   params.action = "update"
    //   params.args["data"] = { deleted: true }
    // }
  }
  return next(params)
})

export * from "@prisma/client"
export default prisma
