import { SessionContext, SimpleRolesIsAuthorized } from "@blitzjs/auth";
// @ts-ignore
import { User } from "db"

// Note: You should switch to Postgres and then use a DB enum for role type
export type Role = "ADMIN" | "USER"
export type SelectableTimer = "planned" | "session" //|"today" |  "pomodoro" | "money"
export type DateRange =
  | "Today"
  | "Week"
  | "Month"
  | "Yesterday"
  | "Last 7 days"
  | "Last week"
  | "Last 30 days"
  | { from: Date; unill: Date }

declare module "@blitzjs/auth" {
  export interface Ctx {
    session: SessionContext
  }

  export interface Session {
    isAuthorized: SimpleRolesIsAuthorized<Role>
    PublicData: {
      userId: User["id"]
      role: Role
      projectId: string
    }
  }
}
